<?php $__env->startSection('title', 'Yeni Sözleşme'); ?>
<?php $__env->startSection('page-title', 'Yeni Sözleşme'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni bir sözleşme ekleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.contracts.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="employee_id" class="form-label">Çalışan</label>
                        <select name="employee_id" id="employee_id" required class="form-select">
                            <option value="">Seçiniz</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>" 
                                    data-company="<?php echo e($employee->company->name); ?>"
                                    data-branch="<?php echo e($employee->branch->name); ?>"
                                    <?php echo e(old('employee_id', request('employee_id')) == $employee->id ? 'selected' : ''); ?>>
                                    <?php echo e($employee->full_name); ?> - <?php echo e($employee->company->name); ?> / <?php echo e($employee->branch->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div id="employeeInfo" class="mt-2 text-muted small" style="display: none;">
                            <span id="companyInfo"></span> / <span id="branchInfo"></span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="effective_from" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" name="effective_from" id="effective_from" value="<?php echo e(old('effective_from')); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="effective_to" class="form-label">Bitiş Tarihi (Opsiyonel)</label>
                            <input type="date" name="effective_to" id="effective_to" value="<?php echo e(old('effective_to')); ?>"
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="monthly_net_salary" class="form-label">Aylık Net Maaş</label>
                        <input type="number" step="0.01" name="monthly_net_salary" id="monthly_net_salary" value="<?php echo e(old('monthly_net_salary')); ?>" required
                            class="form-control">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pay_day_1" class="form-label">1. Ödeme Günü</label>
                            <input type="number" min="1" max="31" name="pay_day_1" id="pay_day_1" value="<?php echo e(old('pay_day_1', 5)); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="pay_amount_1" class="form-label">1. Ödeme Tutarı</label>
                            <input type="number" step="0.01" name="pay_amount_1" id="pay_amount_1" value="<?php echo e(old('pay_amount_1')); ?>" required
                                class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pay_day_2" class="form-label">2. Ödeme Günü</label>
                            <input type="number" min="1" max="31" name="pay_day_2" id="pay_day_2" value="<?php echo e(old('pay_day_2', 20)); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="pay_amount_2" class="form-label">2. Ödeme Tutarı</label>
                            <input type="number" step="0.01" name="pay_amount_2" id="pay_amount_2" value="<?php echo e(old('pay_amount_2')); ?>" required
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="meal_allowance" class="form-label">Yemek Yardımı</label>
                        <input type="number" step="0.01" name="meal_allowance" id="meal_allowance" value="<?php echo e(old('meal_allowance', 0)); ?>"
                            class="form-control">
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.contracts.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const employeeSelect = document.getElementById('employee_id');
    const employeeInfo = document.getElementById('employeeInfo');
    const companyInfo = document.getElementById('companyInfo');
    const branchInfo = document.getElementById('branchInfo');

    employeeSelect.addEventListener('change', function() {
        const selectedOption = this.options[this.selectedIndex];
        if (selectedOption.value) {
            companyInfo.textContent = selectedOption.getAttribute('data-company');
            branchInfo.textContent = selectedOption.getAttribute('data-branch');
            employeeInfo.style.display = 'block';
        } else {
            employeeInfo.style.display = 'none';
        }
    });

    // Trigger on page load if there's a selected value
    if (employeeSelect.value) {
        employeeSelect.dispatchEvent(new Event('change'));
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/contracts/create.blade.php ENDPATH**/ ?>