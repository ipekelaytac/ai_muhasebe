<?php $__env->startSection('title', 'Finans İşlemleri'); ?>
<?php $__env->startSection('page-title', 'Finans'); ?>
<?php $__env->startSection('page-subtitle', 'Gelir ve gider işlemleri'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">İşlemler</h5>
        <small class="text-muted">Tüm finansal işlemleri görüntüleyin</small>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('admin.finance.reports')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-graph-up me-1"></i>
            Raporlar
        </a>
        <a href="<?php echo e(route('admin.finance.transactions.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>
            Yeni İşlem
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Tip</th>
                        <th>Kategori</th>
                        <th>Açıklama</th>
                        <th class="text-end">Tutar</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($transaction->transaction_date->format('d.m.Y')); ?></td>
                            <td>
                                <span class="badge <?php echo e($transaction->type === 'income' ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($transaction->type === 'income' ? 'Gelir' : 'Gider'); ?>

                                </span>
                            </td>
                            <td><?php echo e($transaction->category->name); ?></td>
                            <td>
                                <div><?php echo e($transaction->description); ?></div>
                                <?php if($transaction->attachments->count() > 0): ?>
                                    <div class="mt-2">
                                        <?php $__currentLoopData = $transaction->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(route('admin.finance.transactions.attachment.show', $attachment)); ?>" target="_blank" class="badge bg-info text-dark text-decoration-none me-1">
                                                <i class="bi bi-file-earmark me-1"></i>
                                                <?php echo e(basename($attachment->file_path)); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-end fw-bold <?php echo e($transaction->type === 'income' ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e(number_format($transaction->amount, 2)); ?> ₺
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.finance.transactions.edit', $transaction)); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.finance.transactions.destroy', $transaction)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Emin misiniz?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz işlem bulunmuyor</p>
                                <a href="<?php echo e(route('admin.finance.transactions.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk işlemi ekleyin
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($transactions->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($transactions->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/finance/transactions/index.blade.php ENDPATH**/ ?>