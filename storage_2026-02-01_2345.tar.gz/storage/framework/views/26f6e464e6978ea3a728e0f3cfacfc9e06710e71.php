<?php $__env->startSection('title', 'Çekler'); ?>
<?php $__env->startSection('page-title', 'Çekler'); ?>
<?php $__env->startSection('page-subtitle', 'Çek yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Çekler</h5>
        <small class="text-muted">Çekleri görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.checks.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Çek
    </a>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.checks.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Çek No, Banka, Cari Ara..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">Tüm Durumlar</option>
                    <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Bekliyor</option>
                    <option value="cashed" <?php echo e(request('status') == 'cashed' ? 'selected' : ''); ?>>Bozduruldu</option>
                    <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>İptal</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="customer_id" class="form-select">
                    <option value="">Tüm Cariler</option>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($customer->id); ?>" <?php echo e(request('customer_id') == $customer->id ? 'selected' : ''); ?>>
                            <?php echo e($customer->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <input type="date" name="date_from" class="form-control" placeholder="Başlangıç" value="<?php echo e(request('date_from')); ?>">
            </div>
            <div class="col-md-2">
                <input type="date" name="date_to" class="form-control" placeholder="Bitiş" value="<?php echo e(request('date_to')); ?>">
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search"></i>
                </button>
            </div>
        </form>
        <?php if(request()->hasAny(['search', 'status', 'customer_id', 'date_from', 'date_to'])): ?>
            <div class="mt-2">
                <a href="<?php echo e(route('admin.checks.index')); ?>" class="btn btn-sm btn-secondary">
                    <i class="bi bi-x-circle me-1"></i>Temizle
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Çek No</th>
                        <th>Banka</th>
                        <th>Cari</th>
                        <th>Tutar</th>
                        <th>Geldiği Tarih</th>
                        <th>Vade Tarihi</th>
                        <th>Bozdurulma Tarihi</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <span class="fw-medium"><?php echo e($check->check_number); ?></span>
                            </td>
                            <td><?php echo e($check->bank_name); ?></td>
                            <td>
                                <div class="fw-medium"><?php echo e($check->customer->name); ?></div>
                                <small class="text-muted"><?php echo e($check->company->name); ?> / <?php echo e($check->branch->name); ?></small>
                            </td>
                            <td class="fw-bold text-primary"><?php echo e(number_format($check->amount, 2)); ?> ₺</td>
                            <td><?php echo e($check->received_date->format('d.m.Y')); ?></td>
                            <td>
                                <span class="<?php echo e($check->due_date->isPast() && $check->status == 'pending' ? 'text-danger' : ''); ?>">
                                    <?php echo e($check->due_date->format('d.m.Y')); ?>

                                </span>
                            </td>
                            <td>
                                <?php echo e($check->cashed_date ? $check->cashed_date->format('d.m.Y') : '-'); ?>

                            </td>
                            <td>
                                <?php if($check->status == 'pending'): ?>
                                    <span class="badge bg-warning">Bekliyor</span>
                                <?php elseif($check->status == 'cashed'): ?>
                                    <span class="badge bg-success">Bozduruldu</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">İptal</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.checks.show', $check)); ?>" class="btn btn-outline-info" title="Detay">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.checks.edit', $check)); ?>" class="btn btn-outline-primary" title="Düzenle">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.checks.destroy', $check)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bu çeki silmek istediğinize emin misiniz?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger" title="Sil">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center py-5">
                                <i class="bi bi-receipt fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz çek bulunmuyor</p>
                                <a href="<?php echo e(route('admin.checks.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk çeki ekleyin
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($checks->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($checks->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/checks/index.blade.php ENDPATH**/ ?>