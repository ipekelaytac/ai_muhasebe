<?php $__env->startSection('title', 'Hareket Düzenle'); ?>
<?php $__env->startSection('page-title', 'Hareket Düzenle - ' . $customer->name); ?>
<?php $__env->startSection('page-subtitle', 'Hareket bilgilerini güncelleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.customers.transactions.update', [$customer, $transaction])); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="type" class="form-label">Tip <span class="text-danger">*</span></label>
                        <select name="type" id="type" required class="form-select">
                            <option value="income" <?php echo e(old('type', $transaction->type) == 'income' ? 'selected' : ''); ?>>Gelir</option>
                            <option value="expense" <?php echo e(old('type', $transaction->type) == 'expense' ? 'selected' : ''); ?>>Gider</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="transaction_date" class="form-label">Tarih <span class="text-danger">*</span></label>
                        <input type="date" name="transaction_date" id="transaction_date" 
                            value="<?php echo e(old('transaction_date', $transaction->transaction_date->format('Y-m-d'))); ?>" required class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="amount" class="form-label">Tutar <span class="text-danger">*</span></label>
                        <div class="input-group">
                            <input type="number" name="amount" id="amount" step="0.01" min="0.01" 
                                value="<?php echo e(old('amount', $transaction->amount)); ?>" required class="form-control" placeholder="0.00">
                            <span class="input-group-text">₺</span>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Açıklama</label>
                        <textarea name="description" id="description" rows="3" class="form-control" placeholder="Açıklama"><?php echo e(old('description', $transaction->description)); ?></textarea>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.customers.show', $customer)); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle me-1"></i>Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/customers/transactions/edit.blade.php ENDPATH**/ ?>