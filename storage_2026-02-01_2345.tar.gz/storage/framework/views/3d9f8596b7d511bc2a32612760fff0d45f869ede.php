<?php $__env->startSection('title', 'Bordro Detay'); ?>
<?php $__env->startSection('page-title', $period->period_name); ?>
<?php $__env->startSection('page-subtitle', $period->company->name . ' - ' . $period->branch->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div></div>
    <div class="btn-group">
        <?php if($items->isEmpty()): ?>
            <form method="POST" action="<?php echo e(route('admin.payroll.generate', $period)); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-plus-circle me-1"></i>
                    Bordro Oluştur
                </button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('admin.payroll.add-employee-form', $period)); ?>" class="btn btn-primary">
                <i class="bi bi-person-plus me-1"></i>
                Personel Ekle
            </a>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.payroll.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-1"></i>
            Geri
        </a>
    </div>
</div>

<?php if($items->isEmpty()): ?>
    <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle me-2"></i>
        Bu dönem için henüz bordro oluşturulmamış. "Bordro Oluştur" butonuna tıklayarak aktif çalışanlar için bordro oluşturabilirsiniz.
    </div>
<?php else: ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Çalışan</th>
                            <th class="text-end">Net Maaş</th>
                            <th class="text-end">Yemek Yardımı</th>
                            <th class="text-end">Net Ödenecek</th>
                            <th class="text-end">Ödenen</th>
                            <th class="text-end">Kalan</th>
                            <th class="text-end">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-medium"><?php echo e($item->employee->full_name); ?></td>
                                <td class="text-end"><?php echo e(number_format($item->base_net_salary, 2)); ?> ₺</td>
                                <td class="text-end text-info fw-medium"><?php echo e(number_format($item->meal_allowance, 2)); ?> ₺</td>
                                <td class="text-end"><?php echo e(number_format($item->net_payable, 2)); ?> ₺</td>
                                <td class="text-end text-success fw-bold"><?php echo e(number_format($item->total_paid, 2)); ?> ₺</td>
                                <td class="text-end text-danger fw-bold"><?php echo e(number_format($item->total_remaining, 2)); ?> ₺</td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('admin.payroll.item', $item)); ?>" class="btn btn-sm btn-outline-primary">
                                        Detay
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th class="fw-bold">TOPLAM</th>
                            <th class="text-end fw-bold"><?php echo e(number_format($items->sum('base_net_salary'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold text-info"><?php echo e(number_format($items->sum('meal_allowance'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold"><?php echo e(number_format($items->sum('net_payable'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold text-success"><?php echo e(number_format($items->sum('total_paid'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold text-danger"><?php echo e(number_format($items->sum('total_remaining'), 2)); ?> ₺</th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/payroll/show.blade.php ENDPATH**/ ?>