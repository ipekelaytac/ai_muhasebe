<?php $__env->startSection('title', 'Şirket Düzenle'); ?>
<?php $__env->startSection('page-title', 'Şirket Düzenle'); ?>
<?php $__env->startSection('page-subtitle', 'Şirket bilgilerini güncelleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.companies.update', $company)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Şirket Adı</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $company->name)); ?>" required
                            class="form-control">
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.companies.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/companies/edit.blade.php ENDPATH**/ ?>