<?php $__env->startSection('title', 'Kesinti Tipleri'); ?>
<?php $__env->startSection('page-title', 'Kesinti Tipleri'); ?>
<?php $__env->startSection('page-subtitle', 'Bordro kesinti tipleri'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Kesinti Tipleri</h5>
        <small class="text-muted">Kesinti tiplerini görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.payroll.deduction-types.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Kesinti Tipi
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Şirket</th>
                        <th>Ad</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $deductionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($type->company->name); ?></td>
                            <td class="fw-medium"><?php echo e($type->name); ?></td>
                            <td>
                                <span class="badge <?php echo e($type->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($type->is_active ? 'Aktif' : 'Pasif'); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.payroll.deduction-types.edit', $type)); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.payroll.deduction-types.destroy', $type)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Emin misiniz?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5">
                                <i class="bi bi-tag fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz kesinti tipi bulunmuyor</p>
                                <a href="<?php echo e(route('admin.payroll.deduction-types.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk kesinti tipini oluşturun
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($deductionTypes->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($deductionTypes->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/payroll/deduction-types/index.blade.php ENDPATH**/ ?>