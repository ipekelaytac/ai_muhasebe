<?php $__env->startSection('title', 'İşlem Düzenle'); ?>
<?php $__env->startSection('page-title', 'İşlem Düzenle'); ?>
<?php $__env->startSection('page-subtitle', 'İşlem bilgilerini güncelleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.finance.transactions.update', $transaction)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="branch_id" class="form-label">Şube</label>
                        <select name="branch_id" id="branch_id" required class="form-select">
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id', $transaction->branch_id) == $branch->id ? 'selected' : ''); ?>>
                                    <?php echo e($branch->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="type" class="form-label">Tip</label>
                            <select name="type" id="type" required class="form-select">
                                <option value="expense" <?php echo e(old('type', $transaction->type) == 'expense' ? 'selected' : ''); ?>>Gider</option>
                                <option value="income" <?php echo e(old('type', $transaction->type) == 'income' ? 'selected' : ''); ?>>Gelir</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="category_id" class="form-label">Kategori</label>
                            <select name="category_id" id="category_id" required class="form-select">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cat->id); ?>" <?php echo e(old('category_id', $transaction->category_id) == $cat->id ? 'selected' : ''); ?>>
                                        <?php echo e($cat->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="transaction_date" class="form-label">Tarih</label>
                        <input type="date" name="transaction_date" id="transaction_date" value="<?php echo e(old('transaction_date', $transaction->transaction_date->format('Y-m-d'))); ?>" required
                            class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="amount" class="form-label">Tutar</label>
                        <input type="number" step="0.01" name="amount" id="amount" value="<?php echo e(old('amount', $transaction->amount)); ?>" required
                            class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Açıklama</label>
                        <textarea name="description" id="description" rows="3" class="form-control"><?php echo e(old('description', $transaction->description)); ?></textarea>
                    </div>
                    
                    <?php if($transaction->attachments->count() > 0): ?>
                        <div class="mb-3">
                            <label class="form-label">Mevcut Ekler</label>
                            <div class="list-group">
                                <?php $__currentLoopData = $transaction->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <div class="flex-grow-1">
                                            <i class="bi bi-paperclip me-2"></i>
                                            <a href="<?php echo e(route('admin.finance.transactions.attachment.show', $attachment)); ?>" target="_blank" class="text-decoration-none">
                                                <i class="bi bi-file-earmark me-1"></i>
                                                <?php echo e(basename($attachment->file_path)); ?>

                                            </a>
                                            <br>
                                            <?php
                                                try {
                                                    $fileSize = \Illuminate\Support\Facades\Storage::disk('public')->size($attachment->file_path);
                                                    $fileSizeKB = number_format($fileSize / 1024, 2);
                                                } catch (\Exception $e) {
                                                    $fileSizeKB = '-';
                                                }
                                            ?>
                                            <small class="text-muted ms-4"><?php echo e($fileSizeKB); ?> KB</small>
                                        </div>
                                        <form action="<?php echo e(route('admin.finance.transactions.attachment.destroy', $attachment)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bu ek dosyasını silmek istediğinizden emin misiniz?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="mb-3">
                        <label for="attachments" class="form-label">Yeni Ekler Ekle (Maksimum 5MB, Birden fazla seçilebilir)</label>
                        <input type="file" name="attachments[]" id="attachments" multiple class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                        <small class="text-muted">PDF, resim veya belge dosyaları yükleyebilirsiniz.</small>
                    </div>
                    
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.finance.transactions.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/finance/transactions/edit.blade.php ENDPATH**/ ?>