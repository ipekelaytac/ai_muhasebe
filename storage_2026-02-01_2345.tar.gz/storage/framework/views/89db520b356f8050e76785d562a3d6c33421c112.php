<?php $__env->startSection('title', 'Yeni Bordro Dönemi'); ?>
<?php $__env->startSection('page-title', 'Yeni Bordro Dönemi'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni bir bordro dönemi oluşturun'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.payroll.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="branch_id" class="form-label">Şube</label>
                        <select name="branch_id" id="branch_id" required class="form-select">
                            <option value="">Seçiniz</option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                    <?php echo e($branch->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="year" class="form-label">Yıl</label>
                            <input type="number" min="2020" max="2100" name="year" id="year" value="<?php echo e(old('year', now()->year)); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="month" class="form-label">Ay</label>
                            <select name="month" id="month" required class="form-select">
                                <?php for($i = 1; $i <= 12; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(old('month', now()->month) == $i ? 'selected' : ''); ?>>
                                        <?php echo e(['', 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][$i]); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.payroll.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Oluştur
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/payroll/create.blade.php ENDPATH**/ ?>