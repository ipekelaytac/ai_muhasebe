<?php $__env->startSection('title', 'Çek Detay'); ?>
<?php $__env->startSection('page-title', 'Çek Detay - ' . $check->check_number); ?>
<?php $__env->startSection('page-subtitle', $check->company->name . ' - ' . $check->branch->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="<?php echo e(route('admin.checks.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Geri
    </a>
    <div>
        <a href="<?php echo e(route('admin.checks.edit', $check)); ?>" class="btn btn-primary">
            <i class="bi bi-pencil me-1"></i>Düzenle
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Tutar</h6>
                <p class="card-text fs-4 fw-bold text-primary mb-0">
                    <?php echo e(number_format($check->amount, 2)); ?> ₺
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Durum</h6>
                <p class="card-text mb-0">
                    <?php if($check->status == 'pending'): ?>
                        <span class="badge bg-warning fs-6">Bekliyor</span>
                    <?php elseif($check->status == 'cashed'): ?>
                        <span class="badge bg-success fs-6">Bozduruldu</span>
                    <?php else: ?>
                        <span class="badge bg-secondary fs-6">İptal</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Vade Tarihi</h6>
                <p class="card-text fs-5 fw-bold <?php echo e($check->due_date->isPast() && $check->status == 'pending' ? 'text-danger' : ''); ?> mb-0">
                    <?php echo e($check->due_date->format('d.m.Y')); ?>

                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Bozdurulma Tarihi</h6>
                <p class="card-text fs-5 fw-bold mb-0">
                    <?php echo e($check->cashed_date ? $check->cashed_date->format('d.m.Y') : '-'); ?>

                </p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">
                <h6 class="mb-0">Çek Bilgileri</h6>
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-4">Çek Numarası:</dt>
                    <dd class="col-sm-8 fw-bold"><?php echo e($check->check_number); ?></dd>

                    <dt class="col-sm-4">Banka:</dt>
                    <dd class="col-sm-8"><?php echo e($check->bank_name); ?></dd>

                    <dt class="col-sm-4">Cari:</dt>
                    <dd class="col-sm-8">
                        <a href="<?php echo e(route('admin.customers.show', $check->customer)); ?>" class="text-decoration-none">
                            <?php echo e($check->customer->name); ?>

                        </a>
                        <span class="badge <?php echo e($check->customer->type == 'customer' ? 'bg-info' : 'bg-warning'); ?> ms-2">
                            <?php echo e($check->customer->type == 'customer' ? 'Müşteri' : 'Tedarikçi'); ?>

                        </span>
                    </dd>

                    <dt class="col-sm-4">Geldiği Tarih:</dt>
                    <dd class="col-sm-8"><?php echo e($check->received_date->format('d.m.Y')); ?></dd>

                    <dt class="col-sm-4">Vade Tarihi:</dt>
                    <dd class="col-sm-8">
                        <span class="<?php echo e($check->due_date->isPast() && $check->status == 'pending' ? 'text-danger fw-bold' : ''); ?>">
                            <?php echo e($check->due_date->format('d.m.Y')); ?>

                        </span>
                        <?php if($check->due_date->isPast() && $check->status == 'pending'): ?>
                            <span class="badge bg-danger ms-2">Vadesi Geçti</span>
                        <?php endif; ?>
                    </dd>

                    <?php if($check->cashed_date): ?>
                    <dt class="col-sm-4">Bozdurulma Tarihi:</dt>
                    <dd class="col-sm-8"><?php echo e($check->cashed_date->format('d.m.Y')); ?></dd>
                    <?php endif; ?>

                    <dt class="col-sm-4">Durum:</dt>
                    <dd class="col-sm-8">
                        <?php if($check->status == 'pending'): ?>
                            <span class="badge bg-warning">Bekliyor</span>
                        <?php elseif($check->status == 'cashed'): ?>
                            <span class="badge bg-success">Bozduruldu</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">İptal</span>
                        <?php endif; ?>
                    </dd>

                    <?php if($check->notes): ?>
                    <dt class="col-sm-4">Notlar:</dt>
                    <dd class="col-sm-8"><?php echo e($check->notes); ?></dd>
                    <?php endif; ?>

                    <dt class="col-sm-4">Oluşturan:</dt>
                    <dd class="col-sm-8"><?php echo e($check->creator->name ?? '-'); ?></dd>

                    <dt class="col-sm-4">Oluşturulma:</dt>
                    <dd class="col-sm-8"><?php echo e($check->created_at->format('d.m.Y H:i')); ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/checks/show.blade.php ENDPATH**/ ?>