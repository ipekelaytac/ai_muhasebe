<?php $__env->startSection('title', 'Borç Detay'); ?>
<?php $__env->startSection('page-title', 'Borç Detay'); ?>
<?php $__env->startSection('page-subtitle', $employeeDebt->employee->full_name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <a href="<?php echo e(route('admin.employee-debts.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>Geri
    </a>
    <div>
        <a href="<?php echo e(route('admin.employee-debts.edit', $employeeDebt)); ?>" class="btn btn-primary">
            <i class="bi bi-pencil me-1"></i>Düzenle
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Borç Tutarı</h6>
                <p class="card-text fs-4 fw-bold text-danger mb-0">
                    <?php echo e(number_format($employeeDebt->amount, 2)); ?> ₺
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Ödenen</h6>
                <p class="card-text fs-4 fw-bold text-success mb-0">
                    <?php echo e(number_format($employeeDebt->paid_amount, 2)); ?> ₺
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Kalan</h6>
                <p class="card-text fs-4 fw-bold <?php echo e($employeeDebt->remaining_amount > 0 ? 'text-danger' : 'text-success'); ?> mb-0">
                    <?php echo e(number_format($employeeDebt->remaining_amount, 2)); ?> ₺
                </p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Durum</h6>
                <p class="card-text mb-0">
                    <span class="badge <?php echo e($employeeDebt->status ? 'bg-warning' : 'bg-success'); ?> fs-6">
                        <?php echo e($employeeDebt->status ? 'Açık' : 'Kapalı'); ?>

                    </span>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">
                <h6 class="mb-0">Borç Bilgileri</h6>
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-4">Personel:</dt>
                    <dd class="col-sm-8 fw-bold"><?php echo e($employeeDebt->employee->full_name); ?></dd>

                    <dt class="col-sm-4">Şirket / Şube:</dt>
                    <dd class="col-sm-8"><?php echo e($employeeDebt->company->name); ?> / <?php echo e($employeeDebt->branch->name); ?></dd>

                    <dt class="col-sm-4">Borç Tarihi:</dt>
                    <dd class="col-sm-8"><?php echo e($employeeDebt->debt_date->format('d.m.Y')); ?></dd>

                    <dt class="col-sm-4">Borç Tutarı:</dt>
                    <dd class="col-sm-8 fw-bold text-danger"><?php echo e(number_format($employeeDebt->amount, 2)); ?> ₺</dd>

                    <?php if($employeeDebt->description): ?>
                    <dt class="col-sm-4">Açıklama:</dt>
                    <dd class="col-sm-8"><?php echo e($employeeDebt->description); ?></dd>
                    <?php endif; ?>

                    <dt class="col-sm-4">Oluşturan:</dt>
                    <dd class="col-sm-8"><?php echo e($employeeDebt->creator->name ?? '-'); ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-light">
        <h6 class="mb-0">Ödemeler</h6>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Ödeme Tarihi</th>
                        <th>Tutar</th>
                        <th>Bordro</th>
                        <th>Notlar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $employeeDebt->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($payment->payment_date->format('d.m.Y')); ?></td>
                            <td class="fw-bold text-success"><?php echo e(number_format($payment->amount, 2)); ?> ₺</td>
                            <td>
                                <?php if($payment->payrollItem): ?>
                                    <a href="<?php echo e(route('admin.payroll.item', $payment->payrollItem)); ?>" class="text-decoration-none">
                                        <?php echo e($payment->payrollItem->payrollPeriod->period_name); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($payment->notes ?? '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-0">Henüz ödeme bulunmuyor</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/employee-debts/show.blade.php ENDPATH**/ ?>