<?php $__env->startSection('title', 'Yeni Çalışan'); ?>
<?php $__env->startSection('page-title', 'Yeni Çalışan'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni bir çalışan ekleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.employees.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="branch_id" class="form-label">Şube</label>
                        <select name="branch_id" id="branch_id" required class="form-select">
                            <option value="">Seçiniz</option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                    <?php echo e($branch->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Ad Soyad</label>
                        <input type="text" name="full_name" id="full_name" value="<?php echo e(old('full_name')); ?>" required
                            class="form-control" placeholder="Çalışanın adı ve soyadı">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="phone" class="form-label">Telefon</label>
                            <input type="text" name="phone" id="phone" value="<?php echo e(old('phone')); ?>"
                                class="form-control" placeholder="0532 123 4567">
                        </div>
                        <div class="col-md-6">
                            <label for="start_date" class="form-label">İşe Başlama Tarihi</label>
                            <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>"
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="status" value="1" id="status" <?php echo e(old('status', true) ? 'checked' : ''); ?> class="form-check-input">
                        <label class="form-check-label" for="status">Aktif</label>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/employees/create.blade.php ENDPATH**/ ?>