<?php $__env->startSection('title', 'Yeni Borç'); ?>
<?php $__env->startSection('page-title', 'Yeni Borç'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni bir borç ekleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.employee-debts.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="branch_id" class="form-label">Şube <span class="text-danger">*</span></label>
                            <select name="branch_id" id="branch_id" required class="form-select">
                                <option value="">Seçiniz</option>
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                        <?php echo e($branch->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="employee_id" class="form-label">Personel <span class="text-danger">*</span></label>
                            <select name="employee_id" id="employee_id" required class="form-select">
                                <option value="">Seçiniz</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>" <?php echo e(old('employee_id', $selectedEmployeeId ?? '') == $employee->id ? 'selected' : ''); ?>>
                                        <?php echo e($employee->full_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="debt_date" class="form-label">Borç Tarihi <span class="text-danger">*</span></label>
                            <input type="date" name="debt_date" id="debt_date" 
                                value="<?php echo e(old('debt_date', date('Y-m-d'))); ?>" required class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="amount" class="form-label">Borç Tutarı <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="number" name="amount" id="amount" step="0.01" min="0.01" 
                                    value="<?php echo e(old('amount')); ?>" required class="form-control" placeholder="0.00">
                                <span class="input-group-text">₺</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label for="description" class="form-label">Açıklama</label>
                            <textarea name="description" id="description" rows="3" class="form-control" placeholder="Borç açıklaması"><?php echo e(old('description')); ?></textarea>
                        </div>
                        <div class="col-md-12">
                            <div class="form-check">
                                <input type="checkbox" name="status" value="1" id="status" <?php echo e(old('status', true) ? 'checked' : ''); ?> class="form-check-input">
                                <label class="form-check-label" for="status">Açık</label>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end gap-2 mt-4">
                        <a href="<?php echo e(route('admin.employee-debts.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle me-1"></i>Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/employee-debts/create.blade.php ENDPATH**/ ?>