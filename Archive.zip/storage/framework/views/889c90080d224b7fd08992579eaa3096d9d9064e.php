<?php $__env->startSection('title', 'Raporlar'); ?>
<?php $__env->startSection('page-title', 'Raporlar'); ?>
<?php $__env->startSection('page-subtitle', 'Detaylı analiz ve raporlar'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.reports.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label for="year" class="form-label">Yıl</label>
                <select name="year" id="year" class="form-select">
                    <?php for($y = now()->year; $y >= now()->year - 5; $y--): ?>
                        <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="month" class="form-label">Ay (Tümü için boş bırakın)</label>
                <select name="month" id="month" class="form-select">
                    <option value="">Tüm Aylar</option>
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                            <?php echo e(['', 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'][$m]); ?>

                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="type" class="form-label">Rapor Tipi</label>
                <select name="type" id="type" class="form-select">
                    <option value="all" <?php echo e($reportType == 'all' ? 'selected' : ''); ?>>Tüm Raporlar</option>
                    <option value="payroll" <?php echo e($reportType == 'payroll' ? 'selected' : ''); ?>>Bordro Raporu</option>
                    <option value="employee" <?php echo e($reportType == 'employee' ? 'selected' : ''); ?>>Çalışan Raporu</option>
                    <option value="advance" <?php echo e($reportType == 'advance' ? 'selected' : ''); ?>>Avans Raporu</option>
                    <option value="deduction" <?php echo e($reportType == 'deduction' ? 'selected' : ''); ?>>Kesinti Raporu</option>
                    <option value="finance" <?php echo e($reportType == 'finance' ? 'selected' : ''); ?>>Finans Raporu</option>
                    <option value="meal" <?php echo e($reportType == 'meal' ? 'selected' : ''); ?>>Yemek Yardımı Raporu</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>
                    Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<?php if($reportType == 'all' || $reportType == 'payroll'): ?>
    <?php if(isset($data['payroll'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-cash-coin me-2"></i>Bordro Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Net Maaş</div>
                                <div class="h4 text-primary mb-0"><?php echo e(number_format($data['payroll']['total_net_salary'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Yemek Yardımı</div>
                                <div class="h4 text-success mb-0"><?php echo e(number_format($data['payroll']['total_meal_allowance'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Ödenebilir</div>
                                <div class="h4 text-info mb-0"><?php echo e(number_format($data['payroll']['total_net_payable'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Kalan Ödeme</div>
                                <div class="h4 <?php echo e($data['payroll']['total_remaining'] > 0 ? 'text-warning' : 'text-success'); ?> mb-0">
                                    <?php echo e(number_format($data['payroll']['total_remaining'], 2)); ?> ₺
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Bonus</div>
                                <div class="h5 text-success mb-0"><?php echo e(number_format($data['payroll']['total_bonus'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Kesinti</div>
                                <div class="h5 text-danger mb-0"><?php echo e(number_format($data['payroll']['total_deduction'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Avans Kesintileri</div>
                                <div class="h5 text-warning mb-0"><?php echo e(number_format($data['payroll']['total_advances_deducted'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Çalışan Sayısı</div>
                                <div class="h5 text-primary mb-0"><?php echo e($data['payroll']['employee_count']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' || $reportType == 'employee'): ?>
    <?php if(isset($data['employee'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0"><i class="bi bi-people me-2"></i>Çalışan Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Çalışan</div>
                                <div class="h4 text-primary mb-0"><?php echo e($data['employee']['total']); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Aktif Çalışan</div>
                                <div class="h4 text-success mb-0"><?php echo e($data['employee']['active']); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Pasif Çalışan</div>
                                <div class="h4 text-secondary mb-0"><?php echo e($data['employee']['inactive']); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Sözleşmeli</div>
                                <div class="h4 text-info mb-0"><?php echo e($data['employee']['with_contract']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' || $reportType == 'advance'): ?>
    <?php if(isset($data['advance'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-cash-stack me-2"></i>Avans Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Avans</div>
                                <div class="h4 text-primary mb-0"><?php echo e(number_format($data['advance']['total_amount'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Ödenen</div>
                                <div class="h4 text-success mb-0"><?php echo e(number_format($data['advance']['total_settled'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Kalan</div>
                                <div class="h4 text-warning mb-0"><?php echo e(number_format($data['advance']['total_remaining'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Açık Avans</div>
                                <div class="h4 text-danger mb-0"><?php echo e($data['advance']['open_count']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' || $reportType == 'deduction'): ?>
    <?php if(isset($data['deduction'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0"><i class="bi bi-tag me-2"></i>Kesinti Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Kesinti</div>
                                <div class="h4 text-danger mb-0"><?php echo e(number_format($data['deduction']['total_amount'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Kesinti Sayısı</div>
                                <div class="h4 text-primary mb-0"><?php echo e($data['deduction']['count']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($data['deduction']['by_type']->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Kesinti Tipi</th>
                                    <th class="text-end">Toplam Tutar</th>
                                    <th class="text-end">Adet</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data['deduction']['by_type']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($type); ?></td>
                                        <td class="text-end"><?php echo e(number_format($info['total'], 2)); ?> ₺</td>
                                        <td class="text-end"><?php echo e($info['count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' || $reportType == 'finance'): ?>
    <?php if(isset($data['finance'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i>Finans Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Gelir</div>
                                <div class="h4 text-success mb-0"><?php echo e(number_format($data['finance']['total_income'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Gider</div>
                                <div class="h4 text-danger mb-0"><?php echo e(number_format($data['finance']['total_expense'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Net</div>
                                <div class="h4 <?php echo e($data['finance']['net'] >= 0 ? 'text-success' : 'text-danger'); ?> mb-0">
                                    <?php echo e(number_format($data['finance']['net'], 2)); ?> ₺
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if($data['finance']['by_category']->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>Kategori</th>
                                    <th class="text-end">Gelir</th>
                                    <th class="text-end">Gider</th>
                                    <th class="text-end">Net</th>
                                    <th class="text-end">İşlem Sayısı</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data['finance']['by_category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($category); ?></td>
                                        <td class="text-end text-success"><?php echo e(number_format($info['income'], 2)); ?> ₺</td>
                                        <td class="text-end text-danger"><?php echo e(number_format($info['expense'], 2)); ?> ₺</td>
                                        <td class="text-end <?php echo e(($info['income'] - $info['expense']) >= 0 ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo e(number_format($info['income'] - $info['expense'], 2)); ?> ₺
                                        </td>
                                        <td class="text-end"><?php echo e($info['count']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' || $reportType == 'meal'): ?>
    <?php if(isset($data['meal'])): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-warning text-dark">
                <h5 class="mb-0"><i class="bi bi-egg-fried me-2"></i>Yemek Yardımı Raporu</h5>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Toplam Yemek Yardımı</div>
                                <div class="h4 text-warning mb-0"><?php echo e(number_format($data['meal']['total'], 2)); ?> ₺</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <div class="text-muted small mb-1">Yararlanan Çalışan</div>
                                <div class="h4 text-primary mb-0"><?php echo e($data['meal']['employee_count']); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

<?php if($reportType == 'all' && (!isset($data) || empty($data))): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5">
            <i class="bi bi-inbox display-4 text-muted d-block mb-3"></i>
            <p class="text-muted mb-0">Rapor verisi bulunamadı. Filtreleri değiştirip tekrar deneyin.</p>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>