<?php $__env->startSection('title', 'Sözleşmeler'); ?>
<?php $__env->startSection('page-title', 'Sözleşmeler'); ?>
<?php $__env->startSection('page-subtitle', 'Çalışan sözleşmeleri'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Sözleşmeler</h5>
        <small class="text-muted">Çalışan sözleşmelerini görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.contracts.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Sözleşme
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Çalışan</th>
                        <th>Geçerlilik</th>
                        <th class="text-end">Net Maaş</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-medium"><?php echo e($contract->employee->full_name); ?></td>
                            <td>
                                <?php echo e($contract->effective_from->format('d.m.Y')); ?> - 
                                <?php echo e($contract->effective_to ? $contract->effective_to->format('d.m.Y') : 'Devam ediyor'); ?>

                            </td>
                            <td class="text-end"><?php echo e(number_format($contract->monthly_net_salary, 2)); ?> ₺</td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.contracts.edit', $contract)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil me-1"></i>
                                    Düzenle
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5">
                                <i class="bi bi-file-earmark-text fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz sözleşme bulunmuyor</p>
                                <a href="<?php echo e(route('admin.contracts.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk sözleşmeyi oluşturun
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($contracts->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($contracts->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/contracts/index.blade.php ENDPATH**/ ?>