<?php $__env->startSection('title', 'Cari Detay'); ?>
<?php $__env->startSection('page-title', $party->name); ?>
<?php $__env->startSection('page-subtitle', 'Cari hesap detayı ve ekstre'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Cari Bilgileri</h6>
                <div>
                    <?php if($party->type === 'employee'): ?>
                        <a href="<?php echo e(route('accounting.employees.advances.index', $party)); ?>" class="btn btn-sm btn-outline-warning me-2">
                            <i class="bi bi-cash-coin me-1"></i>Avanslar
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('accounting.parties.edit', $party)); ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil me-1"></i>Düzenle
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <strong>Kod:</strong> <code><?php echo e($party->code); ?></code>
                    </div>
                    <div class="col-md-6">
                        <strong>Tip:</strong> <span class="badge bg-secondary"><?php echo e($party->type_label); ?></span>
                    </div>
                    <?php if($party->tax_number): ?>
                        <div class="col-md-6">
                            <strong>Vergi No:</strong> <?php echo e($party->tax_number); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($party->phone): ?>
                        <div class="col-md-6">
                            <strong>Telefon:</strong> <?php echo e($party->phone); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($party->email): ?>
                        <div class="col-md-6">
                            <strong>E-posta:</strong> <?php echo e($party->email); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($party->address): ?>
                        <div class="col-md-12">
                            <strong>Adres:</strong> <?php echo e($party->address); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Cari Ekstre</h6>
                <div>
                    <a href="<?php echo e(route('accounting.reports.party-statement', $party)); ?>" class="btn btn-sm btn-outline-info">
                        <i class="bi bi-file-earmark-text me-1"></i>Detaylı Rapor
                    </a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Tarih</th>
                                <th>Tip</th>
                                <th>Belge/Ödeme No</th>
                                <th class="text-end">Borç</th>
                                <th class="text-end">Alacak</th>
                                <th class="text-end">Bakiye</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $runningBalance = $statement['opening_balance'];
                            ?>
                            <tr class="table-info">
                                <td colspan="5"><strong>Açılış Bakiyesi</strong></td>
                                <td class="text-end">
                                    <strong><?php echo e(number_format($runningBalance, 2)); ?> ₺</strong>
                                </td>
                            </tr>
                            <?php $__currentLoopData = $statement['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    if ($line['type'] === 'document') {
                                        if ($line['debit'] > 0) {
                                            $runningBalance += $line['debit'];
                                        } else {
                                            $runningBalance -= $line['credit'];
                                        }
                                    } else {
                                        $runningBalance += $line['debit'] - $line['credit'];
                                    }
                                ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($line['date'])->format('d.m.Y')); ?></td>
                                    <td>
                                        <?php if($line['type'] === 'document'): ?>
                                            <span class="badge bg-primary">Belge</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Ödeme</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($line['type'] === 'document'): ?>
                                            <a href="<?php echo e(route('accounting.documents.show', $line['document_id'])); ?>" class="text-decoration-none">
                                                <?php echo e($line['reference']); ?>

                                            </a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('accounting.payments.show', $line['payment_id'])); ?>" class="text-decoration-none">
                                                <?php echo e($line['reference']); ?>

                                            </a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($line['credit'] > 0): ?>
                                            <span class="text-danger"><?php echo e(number_format($line['credit'], 2)); ?> ₺</span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($line['debit'] > 0): ?>
                                            <span class="text-success"><?php echo e(number_format($line['debit'], 2)); ?> ₺</span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if($runningBalance > 0): ?>
                                            <span class="text-success fw-bold">+<?php echo e(number_format($runningBalance, 2)); ?> ₺</span>
                                        <?php elseif($runningBalance < 0): ?>
                                            <span class="text-danger fw-bold"><?php echo e(number_format($runningBalance, 2)); ?> ₺</span>
                                        <?php else: ?>
                                            <span class="text-muted">0,00 ₺</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-warning">
                                <td colspan="5"><strong>Kapanış Bakiyesi</strong></td>
                                <td class="text-end">
                                    <strong><?php echo e(number_format($statement['closing_balance'], 2)); ?> ₺</strong>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Bakiye Özeti</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Alacak:</span>
                        <strong class="text-success"><?php echo e(number_format($party->receivable_balance, 2)); ?> ₺</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Borç:</span>
                        <strong class="text-danger"><?php echo e(number_format($party->payable_balance, 2)); ?> ₺</strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold">Net Bakiye:</span>
                        <?php
                            $balance = $party->balance;
                        ?>
                        <?php if($balance > 0): ?>
                            <strong class="text-success">+<?php echo e(number_format($balance, 2)); ?> ₺</strong>
                        <?php elseif($balance < 0): ?>
                            <strong class="text-danger"><?php echo e(number_format($balance, 2)); ?> ₺</strong>
                        <?php else: ?>
                            <strong class="text-muted">0,00 ₺</strong>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Hızlı İşlemler</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('accounting.documents.create', ['party_id' => $party->id])); ?>" class="btn btn-primary">
                        <i class="bi bi-file-earmark-plus me-1"></i>Yeni Tahakkuk
                    </a>
                    <a href="<?php echo e(route('accounting.payments.create', ['party_id' => $party->id])); ?>" class="btn btn-success">
                        <i class="bi bi-cash-coin me-1"></i>Yeni Ödeme/Tahsilat
                    </a>
                </div>
            </div>
        </div>
        
        <?php if($openDocuments->count() > 0): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Açık Belgeler (<?php echo e($openDocuments->count()); ?>)</h6>
                </div>
                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php $__currentLoopData = $openDocuments->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('accounting.documents.show', $doc)); ?>" class="list-group-item list-group-item-action">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <strong><?php echo e($doc->document_number); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($doc->type_label); ?></small>
                                    </div>
                                    <div class="text-end">
                                        <strong><?php echo e(number_format($doc->unpaid_amount, 2)); ?> ₺</strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($doc->due_date ? $doc->due_date->format('d.m.Y') : '-'); ?></small>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/parties/show.blade.php ENDPATH**/ ?>