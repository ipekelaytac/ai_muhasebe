<?php $__env->startSection('title', 'Mesai Takibi'); ?>
<?php $__env->startSection('page-title', 'Mesai Takibi'); ?>
<?php $__env->startSection('page-subtitle', 'Çalışan mesai kayıtları'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Mesai Kayıtları</h5>
        <small class="text-muted">Çalışan mesai kayıtlarını görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.overtime.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Mesai Ekle
    </a>
</div>


<form method="GET" action="<?php echo e(route('admin.overtime.index')); ?>" class="mb-4">
    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="employee_id" class="form-label">Çalışan</label>
                    <select name="employee_id" id="employee_id" class="form-select">
                        <option value="">Tümü</option>
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($employee->id); ?>" <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                <?php echo e($employee->full_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="start_date" class="form-label">Başlangıç Tarihi</label>
                    <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label for="end_date" class="form-label">Bitiş Tarihi</label>
                    <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-funnel me-1"></i>Filtrele
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>


<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($overtimes->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Tarih</th>
                            <th>Çalışan</th>
                            <th>Başlangıç</th>
                            <th>Bitiş</th>
                            <th>Saat</th>
                            <th>Saatlik Ücret</th>
                            <th class="text-end">Tutar</th>
                            <th>Notlar</th>
                            <th class="text-end">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $overtimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overtime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($overtime->overtime_date->format('d.m.Y')); ?></td>
                                <td>
                                    <strong><?php echo e($overtime->employee->full_name); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($overtime->company->name); ?> - <?php echo e($overtime->branch->name); ?></small>
                                </td>
                                <td><?php echo e(date('H:i', strtotime($overtime->start_time))); ?></td>
                                <td><?php echo e(date('H:i', strtotime($overtime->end_time))); ?></td>
                                <td class="fw-bold"><?php echo e(number_format($overtime->hours, 2)); ?> saat</td>
                                <td><?php echo e(number_format($overtime->rate, 2)); ?> ₺</td>
                                <td class="text-end fw-bold text-success"><?php echo e(number_format($overtime->amount, 2)); ?> ₺</td>
                                <td>
                                    <?php if($overtime->notes): ?>
                                        <small class="text-muted"><?php echo e(Str::limit($overtime->notes, 30)); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.overtime.edit', $overtime)); ?>" class="btn btn-outline-primary" title="Düzenle">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form method="POST" action="<?php echo e(route('admin.overtime.destroy', $overtime)); ?>" class="d-inline" onsubmit="return confirm('Bu mesai kaydını silmek istediğinizden emin misiniz?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-outline-danger" title="Sil">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th colspan="6" class="text-end">Toplam:</th>
                            <th class="text-end"><?php echo e(number_format($overtimes->sum('amount'), 2)); ?> ₺</th>
                            <th colspan="2"></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-3">
                <?php echo e($overtimes->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-clock-history display-4 text-muted mb-3"></i>
                <p class="lead text-muted">Henüz mesai kaydı bulunmuyor.</p>
                <a href="<?php echo e(route('admin.overtime.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-1"></i>
                    İlk Mesai Kaydını Oluştur
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/overtime/index.blade.php ENDPATH**/ ?>