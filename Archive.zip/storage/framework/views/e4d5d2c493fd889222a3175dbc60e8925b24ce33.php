<?php $__env->startSection('title', 'Yeni İşlem'); ?>
<?php $__env->startSection('page-title', 'Yeni İşlem'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni bir finans işlemi ekleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.finance.transactions.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="branch_id" class="form-label">Şube</label>
                        <select name="branch_id" id="branch_id" required class="form-select">
                            <option value="">Seçiniz</option>
                            <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                    <?php echo e($branch->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="type" class="form-label">Tip</label>
                            <select name="type" id="type" required class="form-select">
                                <option value="expense" <?php echo e(old('type') == 'expense' ? 'selected' : ''); ?>>Gider</option>
                                <option value="income" <?php echo e(old('type') == 'income' ? 'selected' : ''); ?>>Gelir</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="category_id" class="form-label">Kategori</label>
                            <select name="category_id" id="category_id" required class="form-select">
                                <option value="">Seçiniz</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                                        <?php echo e($category->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="transaction_date" class="form-label">Tarih</label>
                        <input type="date" name="transaction_date" id="transaction_date" value="<?php echo e(old('transaction_date', now()->toDateString())); ?>" required
                            class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="amount" class="form-label">Tutar</label>
                        <input type="number" step="0.01" name="amount" id="amount" value="<?php echo e(old('amount')); ?>" required
                            class="form-control">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Açıklama</label>
                        <textarea name="description" id="description" rows="3" class="form-control"><?php echo e(old('description')); ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="attachments" class="form-label">Ekler (Maksimum 5MB, Birden fazla seçilebilir)</label>
                        <input type="file" name="attachments[]" id="attachments" multiple class="form-control" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                        <small class="text-muted">PDF, resim veya belge dosyaları yükleyebilirsiniz.</small>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.finance.transactions.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Kaydet
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/finance/transactions/create.blade.php ENDPATH**/ ?>