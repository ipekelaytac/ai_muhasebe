<?php $__env->startSection('title', 'Kasa & Bankalar'); ?>
<?php $__env->startSection('page-title', 'Kasa & Bankalar'); ?>
<?php $__env->startSection('page-subtitle', 'Kasa ve banka hesap bakiyeleri'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Kasa ve Banka Bakiyeleri</h5>
        <small class="text-muted">Güncel bakiye durumunu görüntüleyin</small>
    </div>
    <a href="<?php echo e(route('accounting.cash.transfer')); ?>" class="btn btn-info">
        <i class="bi bi-arrow-left-right me-1"></i>
        Virman Yap
    </a>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Kasalar</h6>
                <a href="<?php echo e(route('accounting.cash.cashbox.create')); ?>" class="btn btn-sm btn-success">
                    <i class="bi bi-plus-circle me-1"></i>Ekle
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Kasa</th>
                                <th class="text-end">Bakiye</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $cashboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($cashbox->name); ?></strong>
                                                <?php if($cashbox->code): ?>
                                                    <small class="text-muted">(<?php echo e($cashbox->code); ?>)</small>
                                                <?php endif; ?>
                                                <?php if($cashbox->is_active): ?>
                                                    <span class="badge bg-success ms-2">Aktif</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary ms-2">Pasif</span>
                                                <?php endif; ?>
                                                <?php if($cashbox->is_default): ?>
                                                    <span class="badge bg-primary ms-1">Varsayılan</span>
                                                <?php endif; ?>
                                            </div>
                                            <a href="<?php echo e(route('accounting.cash.cashbox.edit', $cashbox)); ?>" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="text-end">
                                        <strong class="<?php echo e($cashbox->balance >= 0 ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo e(number_format($cashbox->balance, 2)); ?> <?php echo e($cashbox->currency); ?>

                                        </strong>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="text-center py-4 text-muted">
                                        <i class="bi bi-inbox display-6 d-block mb-2"></i>
                                        Henüz kasa tanımlanmamış. 
                                        <a href="<?php echo e(route('accounting.cash.cashbox.create')); ?>" class="text-primary">İlk kasayı ekleyin</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php if(count($cashboxes) > 0 && isset($balances['total_cash'])): ?>
                                <tr class="table-info">
                                    <td><strong>Toplam</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($balances['total_cash'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Banka Hesapları</h6>
                <a href="<?php echo e(route('accounting.cash.bank.create')); ?>" class="btn btn-sm btn-primary">
                    <i class="bi bi-plus-circle me-1"></i>Ekle
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Banka</th>
                                <th class="text-end">Bakiye</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?php echo e($bank->name); ?></strong>
                                                <?php if($bank->code): ?>
                                                    <small class="text-muted">(<?php echo e($bank->code); ?>)</small>
                                                <?php endif; ?>
                                                <br>
                                                <small class="text-muted"><?php echo e($bank->bank_name); ?></small>
                                                <?php if($bank->is_active): ?>
                                                    <span class="badge bg-success ms-2">Aktif</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary ms-2">Pasif</span>
                                                <?php endif; ?>
                                                <?php if($bank->is_default): ?>
                                                    <span class="badge bg-primary ms-1">Varsayılan</span>
                                                <?php endif; ?>
                                            </div>
                                            <a href="<?php echo e(route('accounting.cash.bank.edit', $bank)); ?>" class="btn btn-sm btn-outline-secondary">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                        </div>
                                    </td>
                                    <td class="text-end">
                                        <strong class="<?php echo e($bank->balance >= 0 ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo e(number_format($bank->balance, 2)); ?> <?php echo e($bank->currency); ?>

                                        </strong>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="text-center py-4 text-muted">
                                        <i class="bi bi-bank display-6 d-block mb-2"></i>
                                        Henüz banka hesabı tanımlanmamış. 
                                        <a href="<?php echo e(route('accounting.cash.bank.create')); ?>" class="text-primary">İlk banka hesabını ekleyin</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <?php if(count($bankAccounts) > 0 && isset($balances['total_bank'])): ?>
                                <tr class="table-info">
                                    <td><strong>Toplam</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($balances['total_bank'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($balances['total'])): ?>
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body text-center">
            <h4 class="mb-0">
                Toplam Nakit: 
                <span class="<?php echo e($balances['total'] >= 0 ? 'text-success' : 'text-danger'); ?>">
                    <?php echo e(number_format($balances['total'], 2)); ?> ₺
                </span>
            </h4>
        </div>
    </div>
<?php endif; ?>

<?php if($recentPayments->count() > 0): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-bottom">
            <h6 class="mb-0">Son Ödemeler</h6>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Tarih</th>
                            <th>Cari</th>
                            <th>Tip</th>
                            <th>Kasa/Banka</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-end">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($payment->payment_date->format('d.m.Y')); ?></td>
                                <td>
                                    <?php if($payment->party): ?>
                                        <?php echo e($payment->party->name); ?>

                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge <?php echo e($payment->direction === 'in' ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e($payment->type_label); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($payment->cashbox): ?>
                                        <span class="badge bg-info"><?php echo e($payment->cashbox->name); ?></span>
                                    <?php elseif($payment->bankAccount): ?>
                                        <span class="badge bg-primary"><?php echo e($payment->bankAccount->name); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end"><?php echo e(number_format($payment->amount, 2)); ?> ₺</td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('accounting.payments.show', $payment)); ?>" class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/cash/index.blade.php ENDPATH**/ ?>