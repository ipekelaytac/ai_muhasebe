<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Muhasebe Sistemi'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            width: 250px;
            flex-shrink: 0;
            z-index: 1000;
            overflow: hidden;
        }
        .sidebar-header {
            flex-shrink: 0;
        }
        .sidebar-nav {
            flex: 1 1 auto;
            overflow-y: auto;
            overflow-x: hidden;
            min-height: 0;
        }
        .sidebar-nav::-webkit-scrollbar {
            width: 6px;
        }
        .sidebar-nav::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.1);
        }
        .sidebar-nav::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
        }
        .sidebar-nav::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.5);
        }
        .sidebar-footer {
            flex-shrink: 0;
        }
        .page-footer {
            background-color: #f8f9fa;
            border-top: 1px solid #dee2e6;
            padding: 1rem 1.5rem;
            margin-top: auto;
            text-align: center;
            color: #6c757d;
            font-size: 0.875rem;
        }
        .page-footer a {
            color: #0d6efd;
            text-decoration: none;
        }
        .page-footer a:hover {
            text-decoration: underline;
        }
        @media (max-width: 991.98px) {
            .sidebar {
                position: fixed;
                z-index: 1050;
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                height: 100vh;
                width: 280px !important;
                left: 0;
                top: 0;
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .sidebar-backdrop {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 1040;
            }
            .sidebar-backdrop.show {
                display: block;
            }
            .flex-grow-1 {
                margin-left: 0 !important;
            }
            main {
                padding: 1rem !important;
            }
            .card {
                margin-bottom: 1rem;
            }
            .table-responsive {
                font-size: 0.875rem;
            }
            .btn-group {
                flex-wrap: wrap;
            }
            .btn-group .btn {
                margin-bottom: 0.25rem;
            }
        }
        @media (max-width: 575.98px) {
            main {
                padding: 0.75rem !important;
            }
            .card-body {
                padding: 1rem !important;
            }
            .table {
                font-size: 0.8rem;
            }
            .btn-sm {
                padding: 0.25rem 0.5rem;
                font-size: 0.75rem;
            }
        }
    </style>
</head>
<body class="bg-light" style="overflow-x: hidden;">
    <div class="d-flex" style="min-height: 100vh;">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="flex-grow-1 d-flex flex-column" style="min-width: 0; margin-left: 250px;">
            <?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            
            <main class="flex-grow-1 p-3 p-md-4" style="overflow-x: auto; overflow-y: auto;">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="bi bi-check-circle me-2"></i>
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-circle me-2"></i>
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <strong>Hata!</strong>
                        <ul class="mb-0 mt-2">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
            
            <footer class="page-footer">
                <div class="container-fluid">
                    <p class="mb-0">
                        &copy; <?php echo e(date('Y')); ?> Muhasebe Sistemi. 
                        <a href="https://aytacipekel.com" target="_blank" rel="noopener noreferrer">aytacipekel.com</a>
                    </p>
                </div>
            </footer>
        </div>
    </div>

    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="toggleSidebar()"></div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');
            sidebar.classList.toggle('show');
            backdrop.classList.toggle('show');
        }
        
        function closeSidebarOnMobile() {
            if (window.innerWidth < 992) {
                const sidebar = document.getElementById('sidebar');
                const backdrop = document.getElementById('sidebarBackdrop');
                sidebar.classList.remove('show');
                backdrop.classList.remove('show');
            }
        }
        
        // Close sidebar when clicking backdrop
        document.getElementById('sidebarBackdrop').addEventListener('click', function() {
            closeSidebarOnMobile();
        });
        
        // Close sidebar on window resize if it becomes desktop
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 992) {
                const sidebar = document.getElementById('sidebar');
                const backdrop = document.getElementById('sidebarBackdrop');
                sidebar.classList.remove('show');
                backdrop.classList.remove('show');
            }
        });
    </script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/layouts/admin.blade.php ENDPATH**/ ?>