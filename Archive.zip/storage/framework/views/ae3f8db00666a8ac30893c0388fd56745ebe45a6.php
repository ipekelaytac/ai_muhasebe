<?php $__env->startSection('title', 'Çalışanlar'); ?>
<?php $__env->startSection('page-title', 'Çalışanlar'); ?>
<?php $__env->startSection('page-subtitle', 'Çalışan yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Çalışanlar</h5>
        <small class="text-muted">Çalışanları görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.employees.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Çalışan
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Çalışan</th>
                        <th>Şirket / Şube</th>
                        <th>İletişim</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary bg-opacity-10 rounded-circle d-flex align-items-center justify-content-center me-2" style="width: 40px; height: 40px;">
                                        <span class="text-primary fw-bold"><?php echo e(substr($employee->full_name, 0, 1)); ?></span>
                                    </div>
                                    <span class="fw-medium"><?php echo e($employee->full_name); ?></span>
                                </div>
                            </td>
                            <td>
                                <div class="fw-medium"><?php echo e($employee->company->name); ?></div>
                                <small class="text-muted"><?php echo e($employee->branch->name); ?></small>
                            </td>
                            <td>
                                <i class="bi bi-telephone me-1 text-muted"></i>
                                <?php echo e($employee->phone ?? 'Belirtilmemiş'); ?>

                            </td>
                            <td>
                                <span class="badge <?php echo e($employee->status ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($employee->status ? 'Aktif' : 'Pasif'); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.employees.edit', $employee)); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.employees.toggle-status', $employee)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-warning">
                                            <i class="bi bi-toggle-<?php echo e($employee->status ? 'on' : 'off'); ?>"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <i class="bi bi-people fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz çalışan bulunmuyor</p>
                                <a href="<?php echo e(route('admin.employees.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk çalışanı ekleyin
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($employees->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($employees->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/employees/index.blade.php ENDPATH**/ ?>