<?php $__env->startSection('title', 'Personel Avansları'); ?>
<?php $__env->startSection('page-title', 'Personel Avansları'); ?>
<?php $__env->startSection('page-subtitle', $party->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0"><?php echo e($party->name); ?> - Avanslar</h5>
        <small class="text-muted">Personel avans kayıtlarını görüntüleyin</small>
    </div>
    <div>
        <a href="<?php echo e(route('accounting.parties.show', $party)); ?>" class="btn btn-secondary me-2">
            <i class="bi bi-arrow-left me-1"></i>
            Cariye Dön
        </a>
        <a href="<?php echo e(route('accounting.employees.advances.create', $party)); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-1"></i>
            Avans Ver
        </a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <ul class="mb-0">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white">
        <h6 class="mb-0">Açık Avanslar</h6>
    </div>
    <div class="card-body">
        <?php if(count($openAdvances) > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Belge No</th>
                            <th>Tarih</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-end">Ödenen</th>
                            <th class="text-end">Kalan</th>
                            <th>Durum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $openAdvances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><code><?php echo e($advance['document_number']); ?></code></td>
                                <td><?php echo e(\Carbon\Carbon::parse($advance['document_date'])->format('d.m.Y')); ?></td>
                                <td class="text-end"><?php echo e(number_format($advance['total_amount'], 2)); ?> ₺</td>
                                <td class="text-end"><?php echo e(number_format($advance['paid_amount'], 2)); ?> ₺</td>
                                <td class="text-end fw-bold text-danger"><?php echo e(number_format($advance['unpaid_amount'], 2)); ?> ₺</td>
                                <td>
                                    <?php if($advance['unpaid_amount'] > 0): ?>
                                        <span class="badge bg-warning">Açık</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Kapalı</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-muted mb-0">Açık avans bulunmamaktadır.</p>
        <?php endif; ?>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white">
        <h6 class="mb-0">Tüm Avanslar</h6>
    </div>
    <div class="card-body">
        <?php if($advances->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Belge No</th>
                            <th>Tarih</th>
                            <th class="text-end">Tutar</th>
                            <th class="text-end">Ödenen</th>
                            <th class="text-end">Kalan</th>
                            <th>Durum</th>
                            <th>Açıklama</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $advances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><code><?php echo e($advance->document_number); ?></code></td>
                                <td><?php echo e($advance->document_date->format('d.m.Y')); ?></td>
                                <td class="text-end"><?php echo e(number_format($advance->total_amount, 2)); ?> ₺</td>
                                <td class="text-end"><?php echo e(number_format($advance->paid_amount, 2)); ?> ₺</td>
                                <td class="text-end fw-bold <?php echo e($advance->unpaid_amount > 0 ? 'text-danger' : 'text-success'); ?>">
                                    <?php echo e(number_format($advance->unpaid_amount, 2)); ?> ₺
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($advance->status === 'settled' ? 'success' : ($advance->status === 'partial' ? 'warning' : 'secondary')); ?>">
                                        <?php echo e($advance->status_label); ?>

                                    </span>
                                </td>
                                <td><?php echo e($advance->description); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3">
                <?php echo e($advances->links()); ?>

            </div>
        <?php else: ?>
            <p class="text-muted mb-0">Henüz avans kaydı bulunmamaktadır.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/employees/advances/index.blade.php ENDPATH**/ ?>