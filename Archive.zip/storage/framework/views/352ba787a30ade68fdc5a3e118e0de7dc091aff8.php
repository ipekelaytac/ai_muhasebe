<?php $__env->startSection('title', 'Belge Detay'); ?>
<?php $__env->startSection('page-title', $document->document_number); ?>
<?php $__env->startSection('page-subtitle', $document->type_label); ?>

<?php $__env->startSection('content'); ?>
<?php if($document->isInLockedPeriod()): ?>
    <div class="alert alert-warning">
        <i class="bi bi-lock me-2"></i>
        <strong>Uyarı:</strong> Bu belge kilitli bir dönemde. Değişiklik yapmak için ters kayıt kullanın.
    </div>
<?php endif; ?>

<div class="row mb-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom d-flex justify-content-between align-items-center">
                <h6 class="mb-0">Belge Bilgileri</h6>
                <?php if($document->canModify()): ?>
                    <a href="<?php echo e(route('accounting.documents.edit', $document)); ?>" class="btn btn-sm btn-outline-primary">
                        <i class="bi bi-pencil me-1"></i>Düzenle
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <strong>Belge No:</strong> <?php echo e($document->document_number); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Tip:</strong> 
                        <span class="badge <?php echo e($document->direction === 'receivable' ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($document->type_label); ?>

                        </span>
                    </div>
                    <div class="col-md-6">
                        <strong>Cari:</strong> 
                        <a href="<?php echo e(route('accounting.parties.show', $document->party_id)); ?>" class="text-decoration-none">
                            <?php echo e($document->party->name); ?>

                        </a>
                    </div>
                    <div class="col-md-6">
                        <strong>Durum:</strong> 
                        <?php if($document->status === 'pending'): ?>
                            <span class="badge bg-warning">Bekliyor</span>
                        <?php elseif($document->status === 'partial'): ?>
                            <span class="badge bg-info">Kısmi Ödendi</span>
                        <?php elseif($document->status === 'settled'): ?>
                            <span class="badge bg-success">Kapandı</span>
                        <?php elseif($document->status === 'cancelled'): ?>
                            <span class="badge bg-secondary">İptal</span>
                        <?php elseif($document->status === 'reversed'): ?>
                            <span class="badge bg-dark">Ters Kayıt</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Belge Tarihi:</strong> <?php echo e($document->document_date->format('d.m.Y')); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Vade Tarihi:</strong> 
                        <?php if($document->due_date): ?>
                            <?php echo e($document->due_date->format('d.m.Y')); ?>

                            <?php if($document->due_date < now() && in_array($document->status, ['pending', 'partial'])): ?>
                                <span class="badge bg-danger ms-1">Vadesi Geçti</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Toplam Tutar:</strong> 
                        <span class="fw-bold"><?php echo e(number_format($document->total_amount, 2)); ?> ₺</span>
                    </div>
                    <div class="col-md-6">
                        <strong>Kalan Tutar:</strong> 
                        <span class="fw-bold <?php echo e($document->unpaid_amount > 0 ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e(number_format($document->unpaid_amount, 2)); ?> ₺
                        </span>
                    </div>
                    <?php if($document->reference_number): ?>
                        <div class="col-md-6">
                            <strong>Referans No:</strong> <?php echo e($document->reference_number); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($document->category): ?>
                        <div class="col-md-6">
                            <strong>Kategori:</strong> <?php echo e($document->category->name); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($document->description): ?>
                        <div class="col-md-12">
                            <strong>Açıklama:</strong> <?php echo e($document->description); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($document->notes): ?>
                        <div class="col-md-12">
                            <strong>Notlar:</strong> 
                            <div class="text-muted"><?php echo e(nl2br($document->notes)); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php if($document->activeAllocations->count() > 0): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Kapamalar (<?php echo e($document->activeAllocations->count()); ?>)</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Ödeme No</th>
                                    <th class="text-end">Tutar</th>
                                    <th class="text-end">İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $document->activeAllocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($allocation->allocation_date->format('d.m.Y')); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('accounting.payments.show', $allocation->payment_id)); ?>" class="text-decoration-none">
                                                <?php echo e($allocation->payment->payment_number); ?>

                                            </a>
                                        </td>
                                        <td class="text-end"><?php echo e(number_format($allocation->amount, 2)); ?> ₺</td>
                                        <td class="text-end">
                                            <?php if(!$document->isInLockedPeriod()): ?>
                                                <form action="<?php echo e(route('accounting.allocations.cancel', $allocation)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Bu kapamayı iptal etmek istediğinize emin misiniz?');">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        <i class="bi bi-x-circle"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Özet</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Toplam Tutar:</span>
                        <strong><?php echo e(number_format($document->total_amount, 2)); ?> ₺</strong>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Ödenen:</span>
                        <strong class="text-success"><?php echo e(number_format($document->allocated_amount, 2)); ?> ₺</strong>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold">Kalan:</span>
                        <strong class="<?php echo e($document->unpaid_amount > 0 ? 'text-danger' : 'text-success'); ?>">
                            <?php echo e(number_format($document->unpaid_amount, 2)); ?> ₺
                        </strong>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">İşlemler</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <?php if($document->unpaid_amount > 0): ?>
                        <a href="<?php echo e(route('accounting.payments.create', ['party_id' => $document->party_id])); ?>" class="btn btn-success">
                            <i class="bi bi-cash-coin me-1"></i>Ödeme/Tahsilat Gir
                        </a>
                    <?php endif; ?>
                    
                    <?php if(in_array($document->status, ['pending', 'partial']) && !$document->isInLockedPeriod()): ?>
                        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#cancelModal">
                            <i class="bi bi-x-circle me-1"></i>İptal Et
                        </button>
                    <?php endif; ?>
                    
                    <?php if(!in_array($document->status, ['cancelled', 'reversed'])): ?>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#reverseModal">
                            <i class="bi bi-arrow-counterclockwise me-1"></i>Ters Kayıt
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php if($document->reversedDocument): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Ters Kayıt</h6>
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <a href="<?php echo e(route('accounting.documents.show', $document->reversedDocument)); ?>" class="text-decoration-none">
                            <?php echo e($document->reversedDocument->document_number); ?>

                        </a>
                    </p>
                    <small class="text-muted"><?php echo e($document->reversedDocument->document_date->format('d.m.Y')); ?></small>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if($document->reversalDocument): ?>
            <div class="card border-0 shadow-sm mt-4">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Bu Belge Ters Kayıt</h6>
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <strong>Orijinal Belge:</strong>
                        <a href="<?php echo e(route('accounting.documents.show', $document->reversedDocument)); ?>" class="text-decoration-none">
                            <?php echo e($document->reversedDocument->document_number); ?>

                        </a>
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Cancel Modal -->
<div class="modal fade" id="cancelModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('accounting.documents.cancel', $document)); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Belgeyi İptal Et</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Bu belgeyi iptal etmek istediğinize emin misiniz?</p>
                    <div class="mb-3">
                        <label class="form-label">İptal Nedeni</label>
                        <textarea name="reason" class="form-control" rows="3" placeholder="İptal nedeni..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                    <button type="submit" class="btn btn-warning">İptal Et</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Reverse Modal -->
<div class="modal fade" id="reverseModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(route('accounting.documents.reverse', $document)); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Ters Kayıt Oluştur</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Bu belge için ters kayıt oluşturulacak. Bu işlem geri alınamaz.</p>
                    <div class="mb-3">
                        <label class="form-label">Ters Kayıt Nedeni</label>
                        <textarea name="reason" class="form-control" rows="3" placeholder="Ters kayıt nedeni..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                    <button type="submit" class="btn btn-danger">Ters Kayıt Oluştur</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/documents/show.blade.php ENDPATH**/ ?>