<?php $__env->startSection('title', 'Yeni Tahakkuk'); ?>
<?php $__env->startSection('page-title', 'Yeni Tahakkuk'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni belge oluştur'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('accounting.documents.store')); ?>" id="documentForm">
            <?php echo csrf_field(); ?>
            
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Şube</label>
                    <select name="branch_id" class="form-select <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                <?php echo e($branch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Belge Tipi <span class="text-danger">*</span></label>
                    <select name="type" id="document_type" class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seçiniz</option>
                        <optgroup label="Alacak Belgeleri">
                            <option value="customer_invoice" <?php echo e(old('type') == 'customer_invoice' ? 'selected' : ''); ?>>Satış Faturası</option>
                            <option value="income_due" <?php echo e(old('type') == 'income_due' ? 'selected' : ''); ?>>Gelir Tahakkuku</option>
                            <option value="advance_given" <?php echo e(old('type') == 'advance_given' ? 'selected' : ''); ?>>Verilen Avans</option>
                            <option value="cheque_receivable" <?php echo e(old('type') == 'cheque_receivable' ? 'selected' : ''); ?>>Alınan Çek</option>
                            <option value="adjustment_credit" <?php echo e(old('type') == 'adjustment_credit' ? 'selected' : ''); ?>>Alacak Düzeltme</option>
                        </optgroup>
                        <optgroup label="Borç Belgeleri">
                            <option value="supplier_invoice" <?php echo e(old('type') == 'supplier_invoice' ? 'selected' : ''); ?>>Alım Faturası</option>
                            <option value="expense_due" <?php echo e(old('type') == 'expense_due' ? 'selected' : ''); ?>>Gider Tahakkuku</option>
                            <option value="payroll_due" <?php echo e(old('type') == 'payroll_due' ? 'selected' : ''); ?>>Maaş Tahakkuku</option>
                            <option value="overtime_due" <?php echo e(old('type') == 'overtime_due' ? 'selected' : ''); ?>>Mesai Tahakkuku</option>
                            <option value="meal_due" <?php echo e(old('type') == 'meal_due' ? 'selected' : ''); ?>>Yemek Parası Tahakkuku</option>
                            <option value="advance_received" <?php echo e(old('type') == 'advance_received' ? 'selected' : ''); ?>>Alınan Avans</option>
                            <option value="cheque_payable" <?php echo e(old('type') == 'cheque_payable' ? 'selected' : ''); ?>>Verilen Çek</option>
                            <option value="adjustment_debit" <?php echo e(old('type') == 'adjustment_debit' ? 'selected' : ''); ?>>Borç Düzeltme</option>
                        </optgroup>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <script>
                // Filter party dropdown based on document type
                document.addEventListener('DOMContentLoaded', function() {
                    const documentTypeSelect = document.getElementById('document_type');
                    const partySelect = document.getElementById('party_id');
                    const employeeTypes = <?php echo json_encode(\App\Domain\Accounting\Enums\DocumentType::EMPLOYEE_TYPES, 15, 512) ?>;
                    
                    function filterParties() {
                        const selectedType = documentTypeSelect.value;
                        const optgroups = partySelect.querySelectorAll('optgroup');
                        const options = partySelect.querySelectorAll('option[data-party-type]');
                        
                        if (!selectedType) {
                            // Show all parties
                            optgroups.forEach(opt => opt.style.display = '');
                            options.forEach(opt => opt.style.display = '');
                            return;
                        }
                        
                        const isEmployeeType = employeeTypes.includes(selectedType);
                        
                        optgroups.forEach(optgroup => {
                            const partyType = optgroup.getAttribute('data-party-type');
                            if (isEmployeeType) {
                                // For employee types, show all but highlight employee parties
                                optgroup.style.display = '';
                                if (partyType === 'employee') {
                                    optgroup.style.fontWeight = 'bold';
                                }
                            } else {
                                // For non-employee types, hide employee optgroup by default
                                if (partyType === 'employee') {
                                    optgroup.style.display = 'none';
                                } else {
                                    optgroup.style.display = '';
                                }
                            }
                        });
                    }
                    
                    documentTypeSelect.addEventListener('change', filterParties);
                    filterParties(); // Run on page load
                });
                </script>
                
                <div class="col-md-6">
                    <label class="form-label">Cari <span class="text-danger">*</span></label>
                    <select name="party_id" id="party_id" class="form-select <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seçiniz</option>
                        <?php
                            $groupedParties = $parties->groupBy('type');
                        ?>
                        <?php $__currentLoopData = $groupedParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $typeParties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e(\App\Domain\Accounting\Enums\PartyType::getLabel($type)); ?>" data-party-type="<?php echo e($type); ?>">
                                <?php $__currentLoopData = $typeParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($party->id); ?>" data-party-type="<?php echo e($type); ?>" <?php echo e(old('party_id', $partyId) == $party->id ? 'selected' : ''); ?>>
                                        <?php echo e($party->name); ?><?php if($party->code): ?> (<?php echo e($party->code); ?>)<?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="text-muted">Personeller de bu listede görünür</small>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Belge Tarihi <span class="text-danger">*</span></label>
                    <input type="date" name="document_date" class="form-control <?php $__errorArgs = ['document_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('document_date', now()->toDateString())); ?>" required>
                    <?php $__errorArgs = ['document_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Vade Tarihi</label>
                    <input type="date" name="due_date" class="form-control <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('due_date')); ?>">
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Referans No</label>
                    <input type="text" name="reference_number" class="form-control <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('reference_number')); ?>" placeholder="Fatura no, vb.">
                    <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Kategori</label>
                    <select name="category_id" class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Kategorisiz</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Toplam Tutar <span class="text-danger">*</span></label>
                    <input type="number" name="total_amount" id="total_amount" class="form-control <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('total_amount')); ?>" step="0.01" min="0.01" required>
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Açıklama</label>
                    <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Notlar</label>
                    <textarea name="notes" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="mt-4 d-flex justify-content-between">
                <a href="<?php echo e(route('accounting.documents.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Geri
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-circle me-1"></i>Kaydet
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Auto-set due date based on document date if not set
    document.getElementById('document_date').addEventListener('change', function() {
        const dueDateInput = document.querySelector('input[name="due_date"]');
        if (!dueDateInput.value) {
            dueDateInput.value = this.value;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/documents/create.blade.php ENDPATH**/ ?>