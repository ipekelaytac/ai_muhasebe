<?php $__env->startSection('title', 'Aylık Kâr/Zarar'); ?>
<?php $__env->startSection('page-title', 'Aylık Kâr/Zarar'); ?>
<?php $__env->startSection('page-subtitle', 'Gelir ve gider raporu'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.reports.monthly-pnl')); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Yıl</label>
                <input type="number" name="year" class="form-control" value="<?php echo e($year); ?>" min="2020" max="2100">
            </div>
            <div class="col-md-3">
                <label class="form-label">Ay</label>
                <select name="month" class="form-select">
                    <?php for($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::create(null, $m, 1)->locale('tr')->monthName); ?>

                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Gelirler</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pnl['income'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td class="text-end">
                                        <strong class="text-success"><?php echo e(number_format($item['amount'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="text-center py-3 text-muted">Gelir bulunmuyor</td>
                                </tr>
                            <?php endif; ?>
                            <?php if(isset($pnl['income_total'])): ?>
                                <tr class="table-success">
                                    <td><strong>Toplam Gelir</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($pnl['income_total'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Giderler</h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $pnl['expense'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item['name']); ?></td>
                                    <td class="text-end">
                                        <strong class="text-danger"><?php echo e(number_format($item['amount'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2" class="text-center py-3 text-muted">Gider bulunmuyor</td>
                                </tr>
                            <?php endif; ?>
                            <?php if(isset($pnl['expense_total'])): ?>
                                <tr class="table-danger">
                                    <td><strong>Toplam Gider</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($pnl['expense_total'], 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($pnl['net_profit'])): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center">
            <h4 class="mb-0">
                Net Kâr/Zarar: 
                <span class="<?php echo e($pnl['net_profit'] >= 0 ? 'text-success' : 'text-danger'); ?>">
                    <?php echo e(number_format($pnl['net_profit'], 2)); ?> ₺
                </span>
            </h4>
            <small class="text-muted"><?php echo e(\Carbon\Carbon::create($year, $month, 1)->locale('tr')->monthName); ?> <?php echo e($year); ?></small>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/reports/monthly-pnl.blade.php ENDPATH**/ ?>