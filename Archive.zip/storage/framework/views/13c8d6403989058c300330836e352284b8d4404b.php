<?php $__env->startSection('title', 'Şube Düzenle'); ?>
<?php $__env->startSection('page-title', 'Şube Düzenle'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow p-6">
    <form method="POST" action="<?php echo e(route('admin.branches.update', $branch)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-4">
            <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Şube Adı</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name', $branch->name)); ?>" required
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
        </div>
        <div class="mb-4">
            <label for="address" class="block text-gray-700 text-sm font-bold mb-2">Adres</label>
            <textarea name="address" id="address" rows="3"
                class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"><?php echo e(old('address', $branch->address)); ?></textarea>
        </div>
        <div class="flex items-center justify-between">
            <a href="<?php echo e(route('admin.branches.index')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                İptal
            </a>
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Güncelle
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/branches/edit.blade.php ENDPATH**/ ?>