<?php $__env->startSection('title', 'Ödemeler / Tahsilatlar'); ?>
<?php $__env->startSection('page-title', 'Ödemeler / Tahsilatlar'); ?>
<?php $__env->startSection('page-subtitle', 'Ödeme ve tahsilat yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Ödemeler</h5>
        <small class="text-muted">Ödeme ve tahsilatları görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('accounting.payments.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Ödeme/Tahsilat
    </a>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.payments.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Ödeme no, açıklama..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <select name="type" class="form-select">
                    <option value="">Tüm Tipler</option>
                    <?php $__currentLoopData = \App\Domain\Accounting\Enums\PaymentType::ALL; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($type); ?>" <?php echo e(request('type') == $type ? 'selected' : ''); ?>>
                            <?php echo e(\App\Domain\Accounting\Enums\PaymentType::getLabel($type)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <select name="direction" class="form-select">
                    <option value="">Tüm Yönler</option>
                    <option value="in" <?php echo e(request('direction') == 'in' ? 'selected' : ''); ?>>Giriş</option>
                    <option value="out" <?php echo e(request('direction') == 'out' ? 'selected' : ''); ?>>Çıkış</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">Tüm Durumlar</option>
                    <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Taslak</option>
                    <option value="confirmed" <?php echo e(request('status') == 'confirmed' ? 'selected' : ''); ?>>Onaylı</option>
                    <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>İptal</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="party_id" class="form-select">
                    <option value="">Tüm Cariler</option>
                    <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($party->id); ?>" <?php echo e(request('party_id') == $party->id ? 'selected' : ''); ?>>
                            <?php echo e($party->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="cashbox_id" class="form-select">
                    <option value="">Tüm Kasalar</option>
                    <?php $__currentLoopData = $cashboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cashbox->id); ?>" <?php echo e(request('cashbox_id') == $cashbox->id ? 'selected' : ''); ?>>
                            <?php echo e($cashbox->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="bank_account_id" class="form-select">
                    <option value="">Tüm Bankalar</option>
                    <?php $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->id); ?>" <?php echo e(request('bank_account_id') == $bank->id ? 'selected' : ''); ?>>
                            <?php echo e($bank->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>" placeholder="Başlangıç">
            </div>
            <div class="col-md-3">
                <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>" placeholder="Bitiş">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
            <div class="col-md-2">
                <?php if(request()->hasAny(['search', 'type', 'direction', 'status', 'party_id', 'cashbox_id', 'bank_account_id', 'start_date', 'end_date'])): ?>
                    <a href="<?php echo e(route('accounting.payments.index')); ?>" class="btn btn-secondary w-100">
                        <i class="bi bi-x-circle me-1"></i>Temizle
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Cari</th>
                        <th>Tip</th>
                        <th>Ödeme No</th>
                        <th>Kasa/Banka</th>
                        <th class="text-end">Tutar</th>
                        <th class="text-end">Dağıtılan</th>
                        <th class="text-end">Kalan</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($payment->payment_date->format('d.m.Y')); ?></td>
                            <td>
                                <?php if($payment->party): ?>
                                    <a href="<?php echo e(route('accounting.parties.show', $payment->party_id)); ?>" class="text-decoration-none">
                                        <?php echo e($payment->party->name); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($payment->direction === 'in' ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($payment->type_label); ?>

                                </span>
                            </td>
                            <td>
                                <a href="<?php echo e(route('accounting.payments.show', $payment)); ?>" class="text-decoration-none">
                                    <?php echo e($payment->payment_number); ?>

                                </a>
                            </td>
                            <td>
                                <?php if($payment->cashbox): ?>
                                    <span class="badge bg-info"><?php echo e($payment->cashbox->name); ?></span>
                                <?php elseif($payment->bankAccount): ?>
                                    <span class="badge bg-primary"><?php echo e($payment->bankAccount->name); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end"><?php echo e(number_format($payment->amount, 2)); ?> ₺</td>
                            <td class="text-end">
                                <?php if($payment->allocated_amount > 0): ?>
                                    <span class="text-success"><?php echo e(number_format($payment->allocated_amount, 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($payment->unallocated_amount > 0): ?>
                                    <strong class="text-warning"><?php echo e(number_format($payment->unallocated_amount, 2)); ?> ₺</strong>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($payment->status === 'draft'): ?>
                                    <span class="badge bg-secondary">Taslak</span>
                                <?php elseif($payment->status === 'confirmed'): ?>
                                    <span class="badge bg-success">Onaylı</span>
                                <?php elseif($payment->status === 'cancelled'): ?>
                                    <span class="badge bg-danger">İptal</span>
                                <?php elseif($payment->status === 'reversed'): ?>
                                    <span class="badge bg-dark">Ters Kayıt</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('accounting.payments.show', $payment)); ?>" class="btn btn-outline-info" title="Detay">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if($payment->canModify()): ?>
                                        <a href="<?php echo e(route('accounting.payments.edit', $payment)); ?>" class="btn btn-outline-primary" title="Düzenle">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-0">Henüz ödeme bulunmuyor</p>
                                <a href="<?php echo e(route('accounting.payments.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                    <i class="bi bi-plus-circle me-1"></i>Yeni Ödeme Oluştur
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($payments->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($payments->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/payments/index.blade.php ENDPATH**/ ?>