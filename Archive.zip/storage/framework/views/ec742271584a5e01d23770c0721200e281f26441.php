<?php $__env->startSection('title', 'Yemek Yardımı Takibi'); ?>
<?php $__env->startSection('page-title', 'Yemek Yardımı Takibi'); ?>
<?php $__env->startSection('page-subtitle', 'Yemek yardımı ödemeleri ve raporları'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Yemek Yardımı Takibi</h5>
        <small class="text-muted">Aylık yemek yardımı ödemelerini görüntüleyin</small>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('admin.meal-allowance.report')); ?>" class="btn btn-outline-primary">
            <i class="bi bi-graph-up me-1"></i>
            Detaylı Rapor
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Toplam Yemek Yardımı</h6>
                <p class="card-text fs-3 fw-bold text-info mb-0"><?php echo e(number_format($summary['total_meal_allowance'], 2)); ?> ₺</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Personel Sayısı</h6>
                <p class="card-text fs-3 fw-bold mb-0"><?php echo e($summary['total_employees']); ?> kişi</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="card-subtitle text-muted mb-2">Ortalama</h6>
                <p class="card-text fs-3 fw-bold mb-0">
                    <?php echo e($summary['total_employees'] > 0 ? number_format($summary['total_meal_allowance'] / $summary['total_employees'], 2) : 0); ?> ₺
                </p>
            </div>
        </div>
    </div>
</div>

<form method="GET" action="<?php echo e(route('admin.meal-allowance.index')); ?>" class="mb-4">
    <div class="row g-3">
        <div class="col-md-4">
            <label for="year" class="form-label">Yıl</label>
            <select name="year" id="year" class="form-select">
                <?php for($y = now()->year; $y >= now()->year - 5; $y--): ?>
                    <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label for="month" class="form-label">Ay</label>
            <select name="month" id="month" class="form-select">
                <?php for($m = 1; $m <= 12; $m++): ?>
                    <option value="<?php echo e($m); ?>" <?php echo e($month == $m ? 'selected' : ''); ?>>
                        <?php echo e(\Carbon\Carbon::create(null, $m, 1)->locale('tr')->monthName); ?>

                    </option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <button type="submit" class="btn btn-primary w-100">
                <i class="bi bi-search me-1"></i>Filtrele
            </button>
        </div>
    </div>
</form>

<?php if($items->isEmpty()): ?>
    <div class="alert alert-info text-center">
        <i class="bi bi-info-circle fs-1 d-block mb-3"></i>
        <p class="mb-0">Seçilen dönem için yemek yardımı kaydı bulunmuyor.</p>
    </div>
<?php else: ?>
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-light">
            <h5 class="mb-0"><?php echo e(\Carbon\Carbon::create($year, $month, 1)->locale('tr')->monthName); ?> <?php echo e($year); ?> - Yemek Yardımı Detayları</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Çalışan</th>
                            <th>Şirket</th>
                            <th>Şube</th>
                            <th class="text-end">Yemek Yardımı</th>
                            <th class="text-end">Net Maaş</th>
                            <th class="text-end">Toplam</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-medium"><?php echo e($item->employee->full_name); ?></td>
                                <td><?php echo e($item->payrollPeriod->company->name); ?></td>
                                <td><?php echo e($item->payrollPeriod->branch->name); ?></td>
                                <td class="text-end text-info fw-bold"><?php echo e(number_format($item->meal_allowance, 2)); ?> ₺</td>
                                <td class="text-end"><?php echo e(number_format($item->base_net_salary, 2)); ?> ₺</td>
                                <td class="text-end fw-bold"><?php echo e(number_format($item->net_payable, 2)); ?> ₺</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr>
                            <th colspan="3" class="fw-bold">TOPLAM</th>
                            <th class="text-end fw-bold text-info"><?php echo e(number_format($items->sum('meal_allowance'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold"><?php echo e(number_format($items->sum('base_net_salary'), 2)); ?> ₺</th>
                            <th class="text-end fw-bold"><?php echo e(number_format($items->sum('net_payable'), 2)); ?> ₺</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/meal-allowance/index.blade.php ENDPATH**/ ?>