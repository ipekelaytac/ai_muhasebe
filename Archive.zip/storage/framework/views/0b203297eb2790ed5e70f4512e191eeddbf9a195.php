<?php $__env->startSection('title', 'Çekler / Senetler'); ?>
<?php $__env->startSection('page-title', 'Çekler / Senetler'); ?>
<?php $__env->startSection('page-subtitle', 'Çek ve senet yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Çekler</h5>
        <small class="text-muted">Çek ve senetleri görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('accounting.cheques.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Çek/Senet
    </a>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.cheques.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <select name="type" class="form-select">
                    <option value="">Tüm Tipler</option>
                    <option value="received" <?php echo e(request('type') == 'received' ? 'selected' : ''); ?>>Alınan</option>
                    <option value="issued" <?php echo e(request('type') == 'issued' ? 'selected' : ''); ?>>Verilen</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="status" class="form-select">
                    <option value="">Tüm Durumlar</option>
                    <option value="in_portfolio" <?php echo e(request('status') == 'in_portfolio' ? 'selected' : ''); ?>>Portföyde</option>
                    <option value="deposited" <?php echo e(request('status') == 'deposited' ? 'selected' : ''); ?>>Bankada</option>
                    <option value="collected" <?php echo e(request('status') == 'collected' ? 'selected' : ''); ?>>Tahsil Edildi</option>
                    <option value="bounced" <?php echo e(request('status') == 'bounced' ? 'selected' : ''); ?>>Karşılıksız</option>
                </select>
            </div>
            <div class="col-md-3">
                <select name="party_id" class="form-select">
                    <option value="">Tüm Cariler</option>
                    <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($party->id); ?>" <?php echo e(request('party_id') == $party->id ? 'selected' : ''); ?>>
                            <?php echo e($party->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Çek No</th>
                        <th>Tarih</th>
                        <th>Vade</th>
                        <th>Cari</th>
                        <th>Banka</th>
                        <th class="text-end">Tutar</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cheques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cheque): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('accounting.cheques.show', $cheque)); ?>" class="text-decoration-none">
                                    <?php echo e($cheque->cheque_number); ?>

                                </a>
                            </td>
                            <td><?php echo e($cheque->issue_date->format('d.m.Y')); ?></td>
                            <td>
                                <?php echo e($cheque->due_date->format('d.m.Y')); ?>

                                <?php if($cheque->due_date < now() && !in_array($cheque->status, ['collected', 'paid', 'bounced', 'cancelled'])): ?>
                                    <span class="badge bg-danger ms-1">Vadesi Geçti</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('accounting.parties.show', $cheque->party_id)); ?>" class="text-decoration-none">
                                    <?php echo e($cheque->party->name); ?>

                                </a>
                            </td>
                            <td><?php echo e($cheque->bank_name); ?></td>
                            <td class="text-end"><?php echo e(number_format($cheque->amount, 2)); ?> ₺</td>
                            <td>
                                <?php if($cheque->status === 'in_portfolio'): ?>
                                    <span class="badge bg-info">Portföyde</span>
                                <?php elseif($cheque->status === 'deposited'): ?>
                                    <span class="badge bg-primary">Bankada</span>
                                <?php elseif($cheque->status === 'collected'): ?>
                                    <span class="badge bg-success">Tahsil Edildi</span>
                                <?php elseif($cheque->status === 'bounced'): ?>
                                    <span class="badge bg-danger">Karşılıksız</span>
                                <?php elseif($cheque->status === 'paid'): ?>
                                    <span class="badge bg-success">Ödendi</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($cheque->status); ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('accounting.cheques.show', $cheque)); ?>" class="btn btn-outline-info" title="Detay">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-0">Henüz çek bulunmuyor</p>
                                <a href="<?php echo e(route('accounting.cheques.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                    <i class="bi bi-plus-circle me-1"></i>Yeni Çek Oluştur
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($cheques->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($cheques->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/cheques/index.blade.php ENDPATH**/ ?>