<?php $__env->startSection('title', 'Ödeme Dağıt'); ?>
<?php $__env->startSection('page-title', 'Ödeme Dağıt'); ?>
<?php $__env->startSection('page-subtitle', $payment->payment_number); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-6">
                <strong>Ödeme No:</strong> <?php echo e($payment->payment_number); ?>

            </div>
            <div class="col-md-6">
                <strong>Tarih:</strong> <?php echo e($payment->payment_date->format('d.m.Y')); ?>

            </div>
            <div class="col-md-6">
                <strong>Tutar:</strong> <?php echo e(number_format($payment->amount, 2)); ?> ₺
            </div>
            <div class="col-md-6">
                <strong>Kalan:</strong> 
                <span class="fw-bold text-warning"><?php echo e(number_format($payment->unallocated_amount, 2)); ?> ₺</span>
            </div>
            <?php if($payment->party): ?>
                <div class="col-md-12">
                    <strong>Cari:</strong> <?php echo e($payment->party->name); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('accounting.allocations.store', $payment)); ?>" id="allocationForm">
            <?php echo csrf_field(); ?>
            
            <div id="allocations-container">
                <?php if($suggestions && count($suggestions) > 0): ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        <strong>Öneri:</strong> En eski vadeli belgeler otomatik seçildi. Gerekirse değiştirebilirsiniz.
                    </div>
                <?php endif; ?>
                
                <div class="table-responsive mb-3">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 50px;">#</th>
                                <th>Belge No</th>
                                <th>Tip</th>
                                <th>Vade</th>
                                <th class="text-end">Toplam</th>
                                <th class="text-end">Kalan</th>
                                <th class="text-end">Dağıtılacak</th>
                                <th style="width: 50px;"></th>
                            </tr>
                        </thead>
                        <tbody id="allocations-tbody">
                            <?php if($suggestions && count($suggestions) > 0): ?>
                                <?php $__currentLoopData = $suggestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $suggestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-document-id="<?php echo e($suggestion['document_id']); ?>">
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('accounting.documents.show', $suggestion['document_id'])); ?>" target="_blank" class="text-decoration-none">
                                                <?php echo e($suggestion['document_number']); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <span class="badge <?php echo e($suggestion['direction'] === 'receivable' ? 'bg-success' : 'bg-danger'); ?>">
                                                <?php echo e($suggestion['type_label']); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($suggestion['due_date']): ?>
                                                <?php echo e(\Carbon\Carbon::parse($suggestion['due_date'])->format('d.m.Y')); ?>

                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end"><?php echo e(number_format($suggestion['total_amount'], 2)); ?> ₺</td>
                                        <td class="text-end">
                                            <strong class="text-danger"><?php echo e(number_format($suggestion['unpaid_amount'], 2)); ?> ₺</strong>
                                        </td>
                                        <td>
                                            <input type="hidden" name="allocations[<?php echo e($index); ?>][document_id]" value="<?php echo e($suggestion['document_id']); ?>">
                                            <input type="number" 
                                                   name="allocations[<?php echo e($index); ?>][amount]" 
                                                   class="form-control allocation-amount" 
                                                   value="<?php echo e(min($suggestion['unpaid_amount'], $payment->unallocated_amount)); ?>" 
                                                   step="0.01" 
                                                   min="0.01" 
                                                   max="<?php echo e($suggestion['unpaid_amount']); ?>"
                                                   data-unpaid="<?php echo e($suggestion['unpaid_amount']); ?>"
                                                   required>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-sm btn-outline-danger remove-row">
                                                <i class="bi bi-x"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr id="no-documents">
                                    <td colspan="8" class="text-center py-4">
                                        <p class="text-muted mb-2">Bu cari için açık belge bulunamadı.</p>
                                        <a href="<?php echo e(route('accounting.documents.create', ['party_id' => $payment->party_id])); ?>" class="btn btn-sm btn-primary">
                                            <i class="bi bi-plus-circle me-1"></i>Yeni Belge Oluştur
                                        </a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="6" class="text-end"><strong>Toplam:</strong></td>
                                <td class="text-end">
                                    <strong id="total-allocated">0,00 ₺</strong>
                                </td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="6" class="text-end"><strong>Kalan:</strong></td>
                                <td class="text-end">
                                    <strong id="remaining-amount" class="text-warning"><?php echo e(number_format($payment->unallocated_amount, 2)); ?> ₺</strong>
                                </td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            
            <div class="mt-4 d-flex justify-content-between">
                <a href="<?php echo e(route('accounting.payments.show', $payment)); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Geri
                </a>
                <button type="submit" class="btn btn-primary" id="submit-btn" <?php echo e((!$suggestions || count($suggestions) == 0) ? 'disabled' : ''); ?>>
                    <i class="bi bi-check-circle me-1"></i>Dağıt
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    let availableAmount = <?php echo e($payment->unallocated_amount); ?>;
    
    function updateTotals() {
        let total = 0;
        document.querySelectorAll('.allocation-amount').forEach(input => {
            const amount = parseFloat(input.value) || 0;
            total += amount;
        });
        
        document.getElementById('total-allocated').textContent = total.toFixed(2).replace('.', ',') + ' ₺';
        
        const remaining = availableAmount - total;
        const remainingEl = document.getElementById('remaining-amount');
        remainingEl.textContent = remaining.toFixed(2).replace('.', ',') + ' ₺';
        
        if (remaining < 0) {
            remainingEl.classList.add('text-danger');
            remainingEl.classList.remove('text-warning');
            document.getElementById('submit-btn').disabled = true;
        } else {
            remainingEl.classList.remove('text-danger');
            remainingEl.classList.add('text-warning');
            document.getElementById('submit-btn').disabled = false;
        }
    }
    
    document.querySelectorAll('.allocation-amount').forEach(input => {
        input.addEventListener('input', function() {
            const max = parseFloat(this.dataset.unpaid);
            if (parseFloat(this.value) > max) {
                this.value = max;
            }
            updateTotals();
        });
    });
    
    document.querySelectorAll('.remove-row').forEach(btn => {
        btn.addEventListener('click', function() {
            this.closest('tr').remove();
            updateTotals();
        });
    });
    
    updateTotals();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/allocations/create.blade.php ENDPATH**/ ?>