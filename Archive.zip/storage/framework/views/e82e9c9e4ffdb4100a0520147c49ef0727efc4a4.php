<?php $__env->startSection('title', 'Cari Ekstre'); ?>
<?php $__env->startSection('page-title', 'Cari Ekstre'); ?>
<?php $__env->startSection('page-subtitle', $party->name); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.reports.party-statement', $party)); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Başlangıç Tarihi</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e($startDate); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label">Bitiş Tarihi</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e($endDate); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Tip</th>
                        <th>Belge/Ödeme No</th>
                        <th class="text-end">Borç</th>
                        <th class="text-end">Alacak</th>
                        <th class="text-end">Bakiye</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $runningBalance = $statement['opening_balance'] ?? 0;
                    ?>
                    <tr class="table-info">
                        <td colspan="5"><strong>Açılış Bakiyesi</strong></td>
                        <td class="text-end">
                            <strong><?php echo e(number_format($runningBalance, 2)); ?> ₺</strong>
                        </td>
                    </tr>
                    <?php $__empty_1 = true; $__currentLoopData = $statement['lines'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            if ($line['type'] === 'document') {
                                if ($line['debit'] > 0) {
                                    $runningBalance += $line['debit'];
                                } else {
                                    $runningBalance -= $line['credit'];
                                }
                            } else {
                                $runningBalance += $line['debit'] - $line['credit'];
                            }
                        ?>
                        <tr>
                            <td><?php echo e(\Carbon\Carbon::parse($line['date'])->format('d.m.Y')); ?></td>
                            <td>
                                <?php if($line['type'] === 'document'): ?>
                                    <span class="badge bg-primary">Belge</span>
                                <?php else: ?>
                                    <span class="badge bg-success">Ödeme</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($line['type'] === 'document'): ?>
                                    <a href="<?php echo e(route('accounting.documents.show', $line['document_id'])); ?>" class="text-decoration-none">
                                        <?php echo e($line['reference']); ?>

                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('accounting.payments.show', $line['payment_id'])); ?>" class="text-decoration-none">
                                        <?php echo e($line['reference']); ?>

                                    </a>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($line['credit'] > 0): ?>
                                    <span class="text-danger"><?php echo e(number_format($line['credit'], 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($line['debit'] > 0): ?>
                                    <span class="text-success"><?php echo e(number_format($line['debit'], 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($runningBalance > 0): ?>
                                    <span class="text-success fw-bold">+<?php echo e(number_format($runningBalance, 2)); ?> ₺</span>
                                <?php elseif($runningBalance < 0): ?>
                                    <span class="text-danger fw-bold"><?php echo e(number_format($runningBalance, 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-0">Bu dönemde işlem bulunmuyor</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr class="table-warning">
                        <td colspan="5"><strong>Kapanış Bakiyesi</strong></td>
                        <td class="text-end">
                            <strong><?php echo e(number_format($statement['closing_balance'] ?? 0, 2)); ?> ₺</strong>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/reports/party-statement.blade.php ENDPATH**/ ?>