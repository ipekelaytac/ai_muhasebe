<?php $__env->startSection('title', 'Cariler'); ?>
<?php $__env->startSection('page-title', 'Cariler'); ?>
<?php $__env->startSection('page-subtitle', 'Cari hesap yönetimi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Cariler</h5>
        <small class="text-muted">Cari hesapları görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('accounting.parties.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Cari
    </a>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.parties.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <input type="text" name="search" class="form-control" placeholder="Ara (isim, kod, vergi no)..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <select name="type" class="form-select">
                    <option value="">Tüm Tipler</option>
                    <option value="customer" <?php echo e(request('type') == 'customer' ? 'selected' : ''); ?>>Müşteri</option>
                    <option value="supplier" <?php echo e(request('type') == 'supplier' ? 'selected' : ''); ?>>Tedarikçi</option>
                    <option value="employee" <?php echo e(request('type') == 'employee' ? 'selected' : ''); ?>>Çalışan</option>
                    <option value="other" <?php echo e(request('type') == 'other' ? 'selected' : ''); ?>>Diğer</option>
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select">
                    <option value="">Tüm Durumlar</option>
                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Aktif</option>
                    <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Pasif</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
            <div class="col-md-3">
                <?php if(request()->hasAny(['search', 'type', 'status'])): ?>
                    <a href="<?php echo e(route('accounting.parties.index')); ?>" class="btn btn-secondary w-100">
                        <i class="bi bi-x-circle me-1"></i>Temizle
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Kod</th>
                        <th>İsim</th>
                        <th>Tip</th>
                        <th class="text-end">Alacak</th>
                        <th class="text-end">Borç</th>
                        <th class="text-end">Net Bakiye</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><code><?php echo e($party->code); ?></code></td>
                            <td>
                                <a href="<?php echo e(route('accounting.parties.show', $party)); ?>" class="text-decoration-none">
                                    <?php echo e($party->name); ?>

                                </a>
                            </td>
                            <td>
                                <span class="badge bg-secondary"><?php echo e($party->type_label); ?></span>
                            </td>
                            <td class="text-end">
                                <?php if($party->receivable_balance > 0): ?>
                                    <span class="text-success fw-bold">+<?php echo e(number_format($party->receivable_balance, 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if($party->payable_balance > 0): ?>
                                    <span class="text-danger fw-bold">-<?php echo e(number_format($party->payable_balance, 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php
                                    $balance = $party->balance;
                                ?>
                                <?php if($balance > 0): ?>
                                    <span class="text-success fw-bold">+<?php echo e(number_format($balance, 2)); ?> ₺</span>
                                <?php elseif($balance < 0): ?>
                                    <span class="text-danger fw-bold"><?php echo e(number_format($balance, 2)); ?> ₺</span>
                                <?php else: ?>
                                    <span class="text-muted">0,00 ₺</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($party->is_active): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Pasif</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('accounting.parties.show', $party)); ?>" class="btn btn-outline-info" title="Detay">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('accounting.parties.edit', $party)); ?>" class="btn btn-outline-primary" title="Düzenle">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="bi bi-inbox fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-0">Henüz cari hesap bulunmuyor</p>
                                <a href="<?php echo e(route('accounting.parties.create')); ?>" class="btn btn-primary btn-sm mt-3">
                                    <i class="bi bi-plus-circle me-1"></i>Yeni Cari Oluştur
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($parties->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($parties->appends(request()->query())->links('vendor.pagination.bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/parties/index.blade.php ENDPATH**/ ?>