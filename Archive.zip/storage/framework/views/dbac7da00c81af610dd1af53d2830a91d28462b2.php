<?php $__env->startSection('title', 'Sözleşme Düzenle'); ?>
<?php $__env->startSection('page-title', 'Sözleşme Düzenle'); ?>
<?php $__env->startSection('page-subtitle', 'Sözleşme bilgilerini güncelleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.contracts.update', $contract)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="mb-3">
                        <label for="employee_id" class="form-label">Çalışan</label>
                        <select name="employee_id" id="employee_id" required class="form-select">
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>" <?php echo e(old('employee_id', $contract->employee_id) == $employee->id ? 'selected' : ''); ?>>
                                    <?php echo e($employee->full_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="effective_from" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" name="effective_from" id="effective_from" value="<?php echo e(old('effective_from', $contract->effective_from->format('Y-m-d'))); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="effective_to" class="form-label">Bitiş Tarihi (Opsiyonel)</label>
                            <input type="date" name="effective_to" id="effective_to" value="<?php echo e(old('effective_to', $contract->effective_to ? $contract->effective_to->format('Y-m-d') : '')); ?>"
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="monthly_net_salary" class="form-label">Aylık Net Maaş</label>
                        <input type="number" step="0.01" name="monthly_net_salary" id="monthly_net_salary" value="<?php echo e(old('monthly_net_salary', $contract->monthly_net_salary)); ?>" required
                            class="form-control">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pay_day_1" class="form-label">1. Ödeme Günü</label>
                            <input type="number" min="1" max="31" name="pay_day_1" id="pay_day_1" value="<?php echo e(old('pay_day_1', $contract->pay_day_1)); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="pay_amount_1" class="form-label">1. Ödeme Tutarı</label>
                            <input type="number" step="0.01" name="pay_amount_1" id="pay_amount_1" value="<?php echo e(old('pay_amount_1', $contract->pay_amount_1)); ?>" required
                                class="form-control">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pay_day_2" class="form-label">2. Ödeme Günü</label>
                            <input type="number" min="1" max="31" name="pay_day_2" id="pay_day_2" value="<?php echo e(old('pay_day_2', $contract->pay_day_2)); ?>" required
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="pay_amount_2" class="form-label">2. Ödeme Tutarı</label>
                            <input type="number" step="0.01" name="pay_amount_2" id="pay_amount_2" value="<?php echo e(old('pay_amount_2', $contract->pay_amount_2)); ?>" required
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="meal_allowance" class="form-label">Yemek Yardımı</label>
                        <input type="number" step="0.01" name="meal_allowance" id="meal_allowance" value="<?php echo e(old('meal_allowance', $contract->meal_allowance)); ?>"
                            class="form-control">
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.contracts.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/contracts/edit.blade.php ENDPATH**/ ?>