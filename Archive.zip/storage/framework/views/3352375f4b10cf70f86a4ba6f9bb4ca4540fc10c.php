<?php $__env->startSection('title', 'Mesai Girişi'); ?>
<?php $__env->startSection('page-title', 'Mesai Girişi'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni mesai tahakkuku oluştur'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Yeni Mesai Girişi</h5>
        <small class="text-muted">Mesai tahakkuku oluşturun</small>
    </div>
    <a href="<?php echo e(route('accounting.overtime.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Geri
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('accounting.overtime.store')); ?>" id="overtimeForm">
            <?php echo csrf_field(); ?>
            
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label">Personel <span class="text-danger">*</span></label>
                    <select name="party_id" id="party_id" class="form-select <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($party->id); ?>" <?php echo e(old('party_id', $partyId) == $party->id ? 'selected' : ''); ?>>
                                <?php echo e($party->name); ?><?php if($party->code): ?> (<?php echo e($party->code); ?>)<?php endif; ?>
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-4">
                    <label class="form-label">Şube</label>
                    <select name="branch_id" class="form-select <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                <?php echo e($branch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-4">
                    <label class="form-label">Belge Tarihi <span class="text-danger">*</span></label>
                    <input type="date" name="document_date" class="form-control <?php $__errorArgs = ['document_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('document_date', now()->toDateString())); ?>" required>
                    <?php $__errorArgs = ['document_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <label class="form-label">Mesai Tarihi <span class="text-danger">*</span></label>
                    <input type="date" name="overtime_date" class="form-control <?php $__errorArgs = ['overtime_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('overtime_date', now()->toDateString())); ?>" required>
                    <?php $__errorArgs = ['overtime_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Saat</label>
                    <input type="number" name="hours" step="0.5" min="0" 
                           class="form-control <?php $__errorArgs = ['hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('hours')); ?>" placeholder="Örn: 2.5" id="hours_input">
                    <?php $__errorArgs = ['hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="text-muted">Mesai saati (opsiyonel)</small>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Saatlik Ücret</label>
                    <div class="input-group">
                        <input type="number" name="rate" step="0.01" min="0" 
                               class="form-control <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('rate')); ?>" placeholder="0.00" id="rate_input" readonly>
                        <span class="input-group-text">₺</span>
                    </div>
                    <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="text-muted" id="rate_info">Personel seçildiğinde otomatik hesaplanır</small>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Toplam Tutar <span class="text-danger">*</span></label>
                    <div class="input-group">
                        <input type="number" name="total_amount" step="0.01" min="0.01" 
                               class="form-control <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               value="<?php echo e(old('total_amount')); ?>" required id="total_amount_input">
                        <span class="input-group-text">₺</span>
                    </div>
                    <?php $__errorArgs = ['total_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Vade Tarihi</label>
                    <input type="date" name="due_date" class="form-control <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('due_date')); ?>">
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Açıklama</label>
                    <input type="text" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                           value="<?php echo e(old('description')); ?>" placeholder="Örn: Hafta sonu mesai">
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="row g-3 mb-4">
                <div class="col-md-12">
                    <label class="form-label">Notlar</label>
                    <textarea name="notes" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3" 
                              placeholder="Ek notlar..."><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="mt-4 d-flex justify-content-between">
                <a href="<?php echo e(route('accounting.overtime.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Geri
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-circle me-1"></i>Kaydet
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const partySelect = document.getElementById('party_id');
    const hoursInput = document.getElementById('hours_input');
    const rateInput = document.getElementById('rate_input');
    const totalInput = document.getElementById('total_amount_input');
    const rateInfo = document.getElementById('rate_info');
    
    let hourlyOvertimeRate = 0;
    
    // Load contract info when party is selected
    partySelect.addEventListener('change', function() {
        const partyId = this.value;
        
        if (!partyId) {
            rateInput.value = '';
            rateInput.setAttribute('readonly', true);
            rateInfo.textContent = 'Personel seçildiğinde otomatik hesaplanır';
            rateInfo.className = 'text-muted';
            hourlyOvertimeRate = 0;
            calculateTotal();
            return;
        }
        
        // Show loading state
        rateInfo.textContent = 'Sözleşme bilgisi yükleniyor...';
        rateInfo.className = 'text-info';
        rateInput.value = '';
        
        // Fetch contract info via AJAX
        const url = `<?php echo e(route('accounting.overtime.contract-info')); ?>?party_id=${partyId}`;
        console.log('Fetching contract info from:', url);
        
        fetch(url, {
            method: 'GET',
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            credentials: 'same-origin'
        })
            .then(response => {
                console.log('Response status:', response.status);
                if (!response.ok) {
                    return response.json().then(data => {
                        console.error('Error response:', data);
                        throw new Error(data.error || 'HTTP ' + response.status);
                    });
                }
                return response.json();
            })
            .then(data => {
                console.log('Contract info received:', data);
                if (data.error) {
                    rateInfo.textContent = data.error;
                    rateInfo.className = 'text-danger';
                    rateInput.value = '';
                    hourlyOvertimeRate = 0;
                } else {
                    hourlyOvertimeRate = parseFloat(data.hourly_overtime_rate) || 0;
                    rateInput.value = hourlyOvertimeRate.toFixed(2);
                    rateInput.setAttribute('readonly', true);
                    rateInfo.textContent = `Aylık maaş: ${parseFloat(data.monthly_salary).toLocaleString('tr-TR', {minimumFractionDigits: 2, maximumFractionDigits: 2})} ₺ | Saatlik mesai ücreti: ${hourlyOvertimeRate.toFixed(2)} ₺`;
                    rateInfo.className = 'text-muted';
                    // Auto-calculate if hours already entered
                    calculateTotal();
                }
            })
            .catch(error => {
                console.error('Error fetching contract info:', error);
                rateInfo.textContent = 'Sözleşme bilgisi alınamadı: ' + error.message;
                rateInfo.className = 'text-danger';
                rateInput.value = '';
                hourlyOvertimeRate = 0;
            });
    });
    
    // Calculate total when hours change
    function calculateTotal() {
        const hours = parseFloat(hoursInput.value) || 0;
        const rate = hourlyOvertimeRate || parseFloat(rateInput.value) || 0;
        
        if (hours > 0 && rate > 0) {
            const calculated = hours * rate;
            // Auto-update total
            totalInput.value = calculated.toFixed(2);
        } else if (hours == 0) {
            // Clear total if hours is 0
            if (!totalInput.value || parseFloat(totalInput.value) == 0) {
                totalInput.value = '';
            }
        }
    }
    
    if (hoursInput && rateInput && totalInput) {
        hoursInput.addEventListener('input', calculateTotal);
        
        // Also allow manual rate entry (if needed)
        rateInput.addEventListener('input', function() {
            if (!this.readOnly) {
                hourlyOvertimeRate = parseFloat(this.value) || 0;
                calculateTotal();
            }
        });
    }
    
    // If party is pre-selected, trigger change event
    <?php if($partyId): ?>
        partySelect.dispatchEvent(new Event('change'));
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/overtime/create.blade.php ENDPATH**/ ?>