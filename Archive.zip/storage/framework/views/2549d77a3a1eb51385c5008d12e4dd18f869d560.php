<?php $__env->startSection('title', 'Bordro'); ?>
<?php $__env->startSection('page-title', 'Bordro'); ?>
<?php $__env->startSection('page-subtitle', 'Bordro dönemleri'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Bordro Dönemleri</h5>
        <small class="text-muted">Bordro dönemlerini görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.payroll.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Dönem
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Dönem</th>
                        <th>Şirket</th>
                        <th>Şube</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-medium"><?php echo e($period->period_name); ?></td>
                            <td><?php echo e($period->company->name); ?></td>
                            <td><?php echo e($period->branch->name); ?></td>
                            <td>
                                <span class="badge <?php echo e($period->status ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($period->status ? 'Açık' : 'Kapalı'); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('admin.payroll.show', $period)); ?>" class="btn btn-sm btn-outline-primary">
                                    Detay
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5">
                                <i class="bi bi-cash-coin fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz dönem bulunmuyor</p>
                                <a href="<?php echo e(route('admin.payroll.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk dönemi oluşturun
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($periods->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($periods->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/payroll/index.blade.php ENDPATH**/ ?>