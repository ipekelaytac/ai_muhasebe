<?php $__env->startSection('title', 'Çalışan Düzenle'); ?>
<?php $__env->startSection('page-title', 'Çalışan Düzenle'); ?>
<?php $__env->startSection('page-subtitle', 'Çalışan bilgilerini güncelleyin'); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('admin.employees.update', $employee)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="company_id" class="form-label">Şirket</label>
                            <select name="company_id" id="company_id" required class="form-select">
                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($company->id); ?>" <?php echo e(old('company_id', $employee->company_id) == $company->id ? 'selected' : ''); ?>>
                                        <?php echo e($company->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="branch_id" class="form-label">Şube</label>
                            <select name="branch_id" id="branch_id" required class="form-select">
                                <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id', $employee->branch_id) == $branch->id ? 'selected' : ''); ?>>
                                        <?php echo e($branch->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="full_name" class="form-label">Ad Soyad</label>
                        <input type="text" name="full_name" id="full_name" value="<?php echo e(old('full_name', $employee->full_name)); ?>" required
                            class="form-control">
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="phone" class="form-label">Telefon</label>
                            <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', $employee->phone)); ?>"
                                class="form-control">
                        </div>
                        <div class="col-md-6">
                            <label for="start_date" class="form-label">İşe Başlama Tarihi</label>
                            <input type="date" name="start_date" id="start_date" value="<?php echo e(old('start_date', $employee->start_date ? $employee->start_date->format('Y-m-d') : '')); ?>"
                                class="form-control">
                        </div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="status" value="1" id="status" <?php echo e(old('status', $employee->status) ? 'checked' : ''); ?> class="form-check-input">
                        <label class="form-check-label" for="status">Aktif</label>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-secondary">
                            İptal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            Güncelle
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/employees/edit.blade.php ENDPATH**/ ?>