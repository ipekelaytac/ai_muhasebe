<?php $__env->startSection('title', 'Avanslar'); ?>
<?php $__env->startSection('page-title', 'Avanslar'); ?>
<?php $__env->startSection('page-subtitle', 'Çalışan avansları'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h5 class="mb-0">Tüm Avanslar</h5>
        <small class="text-muted">Avansları görüntüleyin ve yönetin</small>
    </div>
    <a href="<?php echo e(route('admin.advances.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle me-1"></i>
        Yeni Avans
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Çalışan</th>
                        <th class="text-end">Tutar</th>
                        <th class="text-end">Mahsup Edilen</th>
                        <th class="text-end">Kalan</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $advances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($advance->advance_date->format('d.m.Y')); ?></td>
                            <td>
                                <div class="fw-medium"><?php echo e($advance->employee->full_name); ?></div>
                                <small class="text-muted"><?php echo e($advance->company->name); ?> - <?php echo e($advance->branch->name); ?></small>
                            </td>
                            <td class="text-end fw-medium"><?php echo e(number_format($advance->amount, 2)); ?> ₺</td>
                            <td class="text-end text-success"><?php echo e(number_format($advance->amount - $advance->remaining_amount, 2)); ?> ₺</td>
                            <td class="text-end fw-bold <?php echo e($advance->remaining_amount > 0 ? 'text-warning' : 'text-success'); ?>">
                                <?php echo e(number_format($advance->remaining_amount, 2)); ?> ₺
                            </td>
                            <td>
                                <span class="badge <?php echo e($advance->status ? 'bg-warning' : 'bg-success'); ?>">
                                    <?php echo e($advance->status ? 'Açık' : 'Kapatıldı'); ?>

                                </span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.advances.edit', $advance)); ?>" class="btn btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.advances.destroy', $advance)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Emin misiniz?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5">
                                <i class="bi bi-cash-stack fs-1 text-muted d-block mb-2"></i>
                                <p class="text-muted mb-3">Henüz avans bulunmuyor</p>
                                <a href="<?php echo e(route('admin.advances.create')); ?>" class="btn btn-primary btn-sm">
                                    İlk avansı oluşturun
                                </a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($advances->hasPages()): ?>
        <div class="card-footer bg-white">
            <?php echo e($advances->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/admin/advances/index.blade.php ENDPATH**/ ?>