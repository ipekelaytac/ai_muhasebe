<?php $__env->startSection('title', 'Çek Detay'); ?>
<?php $__env->startSection('page-title', $cheque->cheque_number); ?>
<?php $__env->startSection('page-subtitle', 'Çek detayı ve işlemler'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mb-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Çek Bilgileri</h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <strong>Çek No:</strong> <?php echo e($cheque->cheque_number); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Tip:</strong> 
                        <span class="badge <?php echo e($cheque->type === 'received' ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($cheque->type === 'received' ? 'Alınan' : 'Verilen'); ?>

                        </span>
                    </div>
                    <div class="col-md-6">
                        <strong>Cari:</strong> 
                        <a href="<?php echo e(route('accounting.parties.show', $cheque->party_id)); ?>" class="text-decoration-none">
                            <?php echo e($cheque->party->name); ?>

                        </a>
                    </div>
                    <div class="col-md-6">
                        <strong>Durum:</strong> 
                        <?php if($cheque->status === 'in_portfolio'): ?>
                            <span class="badge bg-info">Portföyde</span>
                        <?php elseif($cheque->status === 'deposited'): ?>
                            <span class="badge bg-primary">Bankada</span>
                        <?php elseif($cheque->status === 'collected'): ?>
                            <span class="badge bg-success">Tahsil Edildi</span>
                        <?php elseif($cheque->status === 'bounced'): ?>
                            <span class="badge bg-danger">Karşılıksız</span>
                        <?php elseif($cheque->status === 'paid'): ?>
                            <span class="badge bg-success">Ödendi</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Kesim Tarihi:</strong> <?php echo e($cheque->issue_date->format('d.m.Y')); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Vade Tarihi:</strong> 
                        <?php echo e($cheque->due_date->format('d.m.Y')); ?>

                        <?php if($cheque->due_date < now() && !in_array($cheque->status, ['collected', 'paid', 'bounced', 'cancelled'])): ?>
                            <span class="badge bg-danger ms-1">Vadesi Geçti</span>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <strong>Banka:</strong> <?php echo e($cheque->bank_name); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Tutar:</strong> 
                        <span class="fw-bold"><?php echo e(number_format($cheque->amount, 2)); ?> ₺</span>
                    </div>
                    <?php if($cheque->bankAccount): ?>
                        <div class="col-md-6">
                            <strong>Banka Hesabı:</strong> <?php echo e($cheque->bankAccount->name); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($cheque->notes): ?>
                        <div class="col-md-12">
                            <strong>Notlar:</strong> 
                            <div class="text-muted"><?php echo e(nl2br($cheque->notes)); ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php if($cheque->document): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">İlişkili Belge</h6>
                </div>
                <div class="card-body">
                    <p class="mb-2">
                        <a href="<?php echo e(route('accounting.documents.show', $cheque->document)); ?>" class="text-decoration-none">
                            <?php echo e($cheque->document->document_number); ?>

                        </a>
                    </p>
                    <small class="text-muted"><?php echo e($cheque->document->document_date->format('d.m.Y')); ?> - <?php echo e(number_format($cheque->document->total_amount, 2)); ?> ₺</small>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">İşlemler</h6>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <?php if($cheque->type === 'received' && $cheque->status === 'in_portfolio'): ?>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#depositModal">
                            <i class="bi bi-bank me-1"></i>Bankaya Ver
                        </button>
                    <?php endif; ?>
                    
                    <?php if($cheque->type === 'received' && in_array($cheque->status, ['in_portfolio', 'deposited'])): ?>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#collectModal">
                            <i class="bi bi-check-circle me-1"></i>Tahsil Et
                        </button>
                    <?php endif; ?>
                    
                    <?php if($cheque->type === 'received' && in_array($cheque->status, ['in_portfolio', 'deposited'])): ?>
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#bounceModal">
                            <i class="bi bi-x-circle me-1"></i>Karşılıksız İşaretle
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Deposit Modal -->
<?php if($cheque->type === 'received' && $cheque->status === 'in_portfolio'): ?>
    <div class="modal fade" id="depositModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(route('accounting.cheques.deposit', $cheque)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Çeki Bankaya Ver</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Banka Hesabı <span class="text-danger">*</span></label>
                            <select name="bank_account_id" class="form-select" required>
                                <option value="">Seçiniz</option>
                                <?php $__currentLoopData = \App\Domain\Accounting\Models\BankAccount::where('company_id', auth()->user()->company_id)->active()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notlar</label>
                            <textarea name="notes" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                        <button type="submit" class="btn btn-primary">Bankaya Ver</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Collect Modal -->
<?php if($cheque->type === 'received' && in_array($cheque->status, ['in_portfolio', 'deposited'])): ?>
    <div class="modal fade" id="collectModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(route('accounting.cheques.collect', $cheque)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Çeki Tahsil Et</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Bu çek tahsil edilecek ve otomatik olarak ödeme kaydı oluşturulacak.</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                        <button type="submit" class="btn btn-success">Tahsil Et</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Bounce Modal -->
<?php if($cheque->type === 'received' && in_array($cheque->status, ['in_portfolio', 'deposited'])): ?>
    <div class="modal fade" id="bounceModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="<?php echo e(route('accounting.cheques.bounce', $cheque)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Çeki Karşılıksız İşaretle</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Neden <span class="text-danger">*</span></label>
                            <textarea name="reason" class="form-control" rows="3" required placeholder="Karşılıksız nedeni..."></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Protesto Ücreti</label>
                            <input type="number" name="fee" class="form-control" step="0.01" min="0" value="0">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Vazgeç</button>
                        <button type="submit" class="btn btn-danger">Karşılıksız İşaretle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/cheques/show.blade.php ENDPATH**/ ?>