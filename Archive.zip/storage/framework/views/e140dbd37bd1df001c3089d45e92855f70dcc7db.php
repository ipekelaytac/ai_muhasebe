<?php $__env->startSection('title', 'Mesai Detay'); ?>
<?php $__env->startSection('page-title', $document->document_number); ?>
<?php $__env->startSection('page-subtitle', 'Mesai Tahakkuku'); ?>

<?php $__env->startSection('content'); ?>
<?php if($document->isInLockedPeriod()): ?>
    <div class="alert alert-warning">
        <i class="bi bi-lock me-2"></i>
        <strong>Uyarı:</strong> Bu belge kilitli bir dönemde. Değişiklik yapmak için ters kayıt kullanın.
    </div>
<?php endif; ?>

<div class="row mb-4">
    <div class="col-md-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-bottom">
                <h6 class="mb-0">Mesai Bilgileri</h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <strong>Belge No:</strong> <?php echo e($document->document_number); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Personel:</strong> 
                        <a href="<?php echo e(route('accounting.parties.show', $document->party_id)); ?>" class="text-decoration-none">
                            <?php echo e($document->party->name); ?>

                        </a>
                    </div>
                    <div class="col-md-6">
                        <strong>Belge Tarihi:</strong> <?php echo e($document->document_date->format('d.m.Y')); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Vade Tarihi:</strong> <?php echo e($document->due_date ? $document->due_date->format('d.m.Y') : '-'); ?>

                    </div>
                    <div class="col-md-6">
                        <strong>Toplam Tutar:</strong> 
                        <span class="fw-bold fs-5 text-primary"><?php echo e(number_format($document->total_amount, 2)); ?> ₺</span>
                    </div>
                    <div class="col-md-6">
                        <strong>Durum:</strong> 
                        <span class="badge bg-<?php echo e($document->status == 'settled' ? 'success' : ($document->status == 'partial' ? 'warning' : 'secondary')); ?>">
                            <?php echo e(\App\Domain\Accounting\Enums\DocumentStatus::getLabel($document->status)); ?>

                        </span>
                    </div>
                    <?php if($document->description): ?>
                        <div class="col-md-12">
                            <strong>Açıklama:</strong> <?php echo e($document->description); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($document->notes): ?>
                        <div class="col-md-12">
                            <strong>Notlar:</strong>
                            <pre class="bg-light p-2 rounded"><?php echo e($document->notes); ?></pre>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <?php if($document->activeAllocations->count() > 0): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Yapılan Ödemeler</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Ödeme No</th>
                                    <th>Tarih</th>
                                    <th>Tutar</th>
                                    <th>Kaynak</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $document->activeAllocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('accounting.payments.show', $allocation->payment_id)); ?>">
                                                <?php echo e($allocation->payment->payment_number); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($allocation->payment->payment_date->format('d.m.Y')); ?></td>
                                        <td class="fw-bold text-success"><?php echo e(number_format($allocation->amount, 2)); ?> ₺</td>
                                        <td>
                                            <?php if($allocation->payment->cashbox): ?>
                                                <span class="badge bg-success">Kasa: <?php echo e($allocation->payment->cashbox->name); ?></span>
                                            <?php elseif($allocation->payment->bankAccount): ?>
                                                <span class="badge bg-primary">Banka: <?php echo e($allocation->payment->bankAccount->name); ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?php echo e($allocation->payment->type_label); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="2">Toplam Ödenen:</th>
                                    <th class="text-success"><?php echo e(number_format($document->paid_amount, 2)); ?> ₺</th>
                                    <th></th>
                                </tr>
                                <tr>
                                    <th colspan="2">Kalan:</th>
                                    <th class="<?php echo e($document->unpaid_amount > 0 ? 'text-warning' : 'text-success'); ?>">
                                        <?php echo e(number_format($document->unpaid_amount, 2)); ?> ₺
                                    </th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col-md-4">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body text-center">
                <h6 class="text-muted mb-2">Toplam Tutar</h6>
                <h3 class="text-primary mb-0"><?php echo e(number_format($document->total_amount, 2)); ?> ₺</h3>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body text-center">
                <h6 class="text-muted mb-2">Ödenen</h6>
                <h4 class="text-success mb-0"><?php echo e(number_format($document->paid_amount, 2)); ?> ₺</h4>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body text-center">
                <h6 class="text-muted mb-2">Kalan</h6>
                <h4 class="<?php echo e($document->unpaid_amount > 0 ? 'text-warning' : 'text-success'); ?> mb-0">
                    <?php echo e(number_format($document->unpaid_amount, 2)); ?> ₺
                </h4>
            </div>
        </div>
        
        <?php if($document->unpaid_amount > 0): ?>
            <div class="d-grid">
                <a href="<?php echo e(route('accounting.payments.create', ['party_id' => $document->party_id, 'document_id' => $document->id])); ?>" 
                   class="btn btn-primary">
                    <i class="bi bi-cash-coin me-1"></i>Ödeme Yap
                </a>
            </div>
        <?php endif; ?>
        
        <div class="mt-3">
            <a href="<?php echo e(route('accounting.overtime.index')); ?>" class="btn btn-outline-secondary w-100">
                <i class="bi bi-arrow-left me-1"></i>Geri
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/overtime/show.blade.php ENDPATH**/ ?>