<?php $__env->startSection('title', 'Yeni Ödeme/Tahsilat'); ?>
<?php $__env->startSection('page-title', 'Yeni Ödeme/Tahsilat'); ?>
<?php $__env->startSection('page-subtitle', 'Yeni ödeme veya tahsilat kaydet'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('accounting.payments.store')); ?>" id="paymentForm">
            <?php echo csrf_field(); ?>
            
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <label class="form-label">Şube</label>
                    <select name="branch_id" class="form-select <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(old('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                <?php echo e($branch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['branch_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Ödeme Tipi <span class="text-danger">*</span></label>
                    <select name="type" id="payment_type" class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Seçiniz</option>
                        <optgroup label="Girişler">
                            <option value="cash_in" <?php echo e(old('type') == 'cash_in' ? 'selected' : ''); ?>>Kasa Girişi</option>
                            <option value="bank_in" <?php echo e(old('type') == 'bank_in' ? 'selected' : ''); ?>>Banka Girişi</option>
                            <option value="pos_in" <?php echo e(old('type') == 'pos_in' ? 'selected' : ''); ?>>POS Tahsilat</option>
                            <option value="cheque_in" <?php echo e(old('type') == 'cheque_in' ? 'selected' : ''); ?>>Çek Tahsilat</option>
                        </optgroup>
                        <optgroup label="Çıkışlar">
                            <option value="cash_out" <?php echo e(old('type') == 'cash_out' ? 'selected' : ''); ?>>Kasa Çıkışı</option>
                            <option value="bank_out" <?php echo e(old('type') == 'bank_out' ? 'selected' : ''); ?>>Banka Çıkışı</option>
                            <option value="cheque_out" <?php echo e(old('type') == 'cheque_out' ? 'selected' : ''); ?>>Çek Ödeme</option>
                        </optgroup>
                        <optgroup label="Transferler">
                            <option value="transfer" <?php echo e(old('type') == 'transfer' ? 'selected' : ''); ?>>Virman</option>
                            <option value="bank_transfer" <?php echo e(old('type') == 'bank_transfer' ? 'selected' : ''); ?>>Havale/EFT</option>
                        </optgroup>
                    </select>
                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Cari</label>
                    <select name="party_id" id="party_id" class="form-select <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz (Opsiyonel)</option>
                        <?php
                            $groupedParties = $parties->groupBy('type');
                        ?>
                        <?php $__currentLoopData = $groupedParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $typeParties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <optgroup label="<?php echo e(\App\Domain\Accounting\Enums\PartyType::getLabel($type)); ?>">
                                <?php $__currentLoopData = $typeParties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($party->id); ?>" <?php echo e(old('party_id', $partyId) == $party->id ? 'selected' : ''); ?>>
                                        <?php echo e($party->name); ?><?php if($party->code): ?> (<?php echo e($party->code); ?>)<?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['party_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <small class="text-muted">Personeller de bu listede görünür</small>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Ödeme Tarihi <span class="text-danger">*</span></label>
                    <input type="date" name="payment_date" class="form-control <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('payment_date', now()->toDateString())); ?>" required>
                    <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Tutar <span class="text-danger">*</span></label>
                    <input type="number" name="amount" id="amount" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount', $suggestedAmount ?? '')); ?>" step="0.01" min="0.01" required>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6" id="cashbox_field" style="display: none;">
                    <label class="form-label">Kasa <span class="text-danger">*</span></label>
                    <select name="cashbox_id" class="form-select <?php $__errorArgs = ['cashbox_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $cashboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cashbox->id); ?>" <?php echo e(old('cashbox_id') == $cashbox->id ? 'selected' : ''); ?>>
                                <?php echo e($cashbox->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['cashbox_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6" id="bank_field" style="display: none;">
                    <label class="form-label">Banka <span class="text-danger">*</span></label>
                    <select name="bank_account_id" class="form-select <?php $__errorArgs = ['bank_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bank->id); ?>" <?php echo e(old('bank_account_id') == $bank->id ? 'selected' : ''); ?>>
                                <?php echo e($bank->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['bank_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6" id="to_cashbox_field" style="display: none;">
                    <label class="form-label">Hedef Kasa</label>
                    <select name="to_cashbox_id" class="form-select <?php $__errorArgs = ['to_cashbox_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $cashboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cashbox->id); ?>" <?php echo e(old('to_cashbox_id') == $cashbox->id ? 'selected' : ''); ?>>
                                <?php echo e($cashbox->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['to_cashbox_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6" id="to_bank_field" style="display: none;">
                    <label class="form-label">Hedef Banka</label>
                    <select name="to_bank_account_id" class="form-select <?php $__errorArgs = ['to_bank_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Seçiniz</option>
                        <?php $__currentLoopData = $bankAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bank->id); ?>" <?php echo e(old('to_bank_account_id') == $bank->id ? 'selected' : ''); ?>>
                                <?php echo e($bank->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['to_bank_account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Komisyon/Ücret</label>
                    <input type="number" name="fee_amount" class="form-control <?php $__errorArgs = ['fee_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('fee_amount')); ?>" step="0.01" min="0">
                    <?php $__errorArgs = ['fee_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Referans No</label>
                    <input type="text" name="reference_number" class="form-control <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('reference_number')); ?>" placeholder="Makbuz no, vb.">
                    <?php $__errorArgs = ['reference_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Açıklama</label>
                    <textarea name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Notlar</label>
                    <textarea name="notes" class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2"><?php echo e(old('notes')); ?></textarea>
                    <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            
            <?php if(isset($openDocuments) && $openDocuments->count() > 0): ?>
                <div class="card border-0 shadow-sm mt-4">
                    <div class="card-header bg-info text-white">
                        <h6 class="mb-0">
                            <i class="bi bi-file-earmark-text me-2"></i>
                            Bu Ödemeyi Hangi Belgeye Dağıtacaksınız?
                        </h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="40">Seç</th>
                                        <th>Belge No</th>
                                        <th>Belge Tarihi</th>
                                        <th>Tür</th>
                                        <th>Açıklama</th>
                                        <th class="text-end">Toplam</th>
                                        <th class="text-end">Ödenen</th>
                                        <th class="text-end">Kalan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $openDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="radio" 
                                                       name="allocation_document_id" 
                                                       value="<?php echo e($doc->id); ?>" 
                                                       class="form-check-input document-radio"
                                                       data-unpaid="<?php echo e($doc->unpaid_amount); ?>"
                                                       <?php echo e((isset($selectedDocument) && $selectedDocument && $selectedDocument->id == $doc->id) ? 'checked' : ''); ?>

                                                       required>
                                            </td>
                                            <td>
                                                <strong><?php echo e($doc->document_number ?? '-'); ?></strong>
                                            </td>
                                            <td><?php echo e($doc->document_date->format('d.m.Y')); ?></td>
                                            <td>
                                                <span class="badge bg-secondary"><?php echo e(\App\Domain\Accounting\Enums\DocumentType::getLabel($doc->type)); ?></span>
                                            </td>
                                            <td>
                                                <small><?php echo e(Str::limit($doc->description, 50)); ?></small>
                                            </td>
                                            <td class="text-end"><?php echo e(number_format($doc->total_amount, 2)); ?> ₺</td>
                                            <td class="text-end text-success"><?php echo e(number_format($doc->paid_amount, 2)); ?> ₺</td>
                                            <td class="text-end fw-bold text-warning"><?php echo e(number_format($doc->unpaid_amount, 2)); ?> ₺</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <small class="text-muted mt-2 d-block">
                            <i class="bi bi-info-circle me-1"></i>
                            Ödeme kaydedildikten sonra seçili belgeye otomatik olarak dağıtılacaktır.
                        </small>
                    </div>
                </div>
            <?php elseif(isset($selectedDocument) && $selectedDocument): ?>
                
                <input type="hidden" name="allocation_document_id" value="<?php echo e($selectedDocument->id); ?>">
                <div class="alert alert-info mt-4">
                    <h6 class="mb-2">
                        <i class="bi bi-file-earmark-check me-2"></i>
                        Seçili Belge
                    </h6>
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <strong><?php echo e($selectedDocument->document_number ?? '-'); ?></strong>
                            <br>
                            <small class="text-muted">
                                <?php echo e($selectedDocument->document_date->format('d.m.Y')); ?>

                                - <?php echo e(\App\Domain\Accounting\Enums\DocumentType::getLabel($selectedDocument->type)); ?>

                            </small>
                        </div>
                        <div class="text-end">
                            <strong><?php echo e(number_format($selectedDocument->unpaid_amount, 2)); ?> ₺</strong>
                            <br>
                            <small class="text-muted">Kalan Tutar</small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            
            <?php if(isset($openOvertimes) && $openOvertimes->count() > 0 && (!isset($openDocuments) || $openDocuments->count() == 0)): ?>
                <div class="alert alert-info mt-4">
                    <h6 class="mb-3">
                        <i class="bi bi-clock-history me-2"></i>
                        Açık Mesai Tahakkukları
                    </h6>
                    <div class="list-group">
                        <?php $__currentLoopData = $openOvertimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $overtimeDoc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo e($overtimeDoc->document_number); ?></strong>
                                        <br>
                                        <small class="text-muted">
                                            <?php echo e($overtimeDoc->document_date->format('d.m.Y')); ?>

                                            <?php if($overtimeDoc->description): ?>
                                                - <?php echo e($overtimeDoc->description); ?>

                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <div class="text-end">
                                        <strong><?php echo e(number_format($overtimeDoc->unpaid_amount, 2)); ?> ₺</strong>
                                        <br>
                                        <small class="text-muted">Kalan</small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <small class="text-muted mt-2 d-block">
                        <i class="bi bi-info-circle me-1"></i>
                        Bu mesai tahakkuklarına ödeme yapmak için yukarıdaki "Belge Seç" bölümünden ilgili belgeyi seçin.
                    </small>
                </div>
            <?php endif; ?>
            
            <div class="mt-4 d-flex justify-content-between">
                <a href="<?php echo e(route('accounting.payments.index')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i>Geri
                </a>
                <button type="submit" class="btn btn-primary">
                    <i class="bi bi-check-circle me-1"></i>Kaydet
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const paymentTypeSelect = document.getElementById('payment_type');
    const cashboxField = document.getElementById('cashbox_field');
    const bankField = document.getElementById('bank_field');
    const toCashboxField = document.getElementById('to_cashbox_field');
    const toBankField = document.getElementById('to_bank_field');
    
    function updateFields() {
        const type = paymentTypeSelect.value;
        const cashTypes = ['cash_in', 'cash_out'];
        const bankTypes = ['bank_in', 'bank_out', 'pos_in', 'cheque_in', 'cheque_out', 'bank_transfer'];
        const transferTypes = ['transfer'];
        
        // Hide all fields first
        cashboxField.style.display = 'none';
        bankField.style.display = 'none';
        toCashboxField.style.display = 'none';
        toBankField.style.display = 'none';
        
        // Show relevant fields
        if (cashTypes.includes(type)) {
            cashboxField.style.display = 'block';
        } else if (bankTypes.includes(type)) {
            bankField.style.display = 'block';
        } else if (transferTypes.includes(type)) {
            cashboxField.style.display = 'block';
            bankField.style.display = 'block';
            toCashboxField.style.display = 'block';
            toBankField.style.display = 'block';
        }
    }
    
    paymentTypeSelect.addEventListener('change', updateFields);
    updateFields(); // Initial call
    
    // Auto-fill amount when document is selected
    const documentRadios = document.querySelectorAll('.document-radio');
    const amountInput = document.getElementById('amount');
    
    documentRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            if (this.checked) {
                const unpaidAmount = parseFloat(this.dataset.unpaid);
                if (unpaidAmount > 0 && (!amountInput.value || amountInput.value == 0)) {
                    amountInput.value = unpaidAmount.toFixed(2);
                }
            }
        });
    });
    
    // If a document is pre-selected, trigger the change event
    const checkedRadio = document.querySelector('.document-radio:checked');
    if (checkedRadio) {
        checkedRadio.dispatchEvent(new Event('change'));
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/payments/create.blade.php ENDPATH**/ ?>