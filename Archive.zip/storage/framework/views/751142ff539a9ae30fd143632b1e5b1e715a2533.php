<?php $__env->startSection('title', 'Kasa & Banka Bakiyeleri'); ?>
<?php $__env->startSection('page-title', 'Kasa & Banka Bakiyeleri'); ?>
<?php $__env->startSection('page-subtitle', 'Güncel bakiye durumu'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('accounting.reports.cash-bank-balance')); ?>" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Tarih</label>
                <input type="date" name="as_of_date" class="form-control" value="<?php echo e($asOfDate); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">&nbsp;</label>
                <button type="submit" class="btn btn-primary w-100">
                    <i class="bi bi-search me-1"></i>Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<div class="row">
    <?php if(isset($balances['cashboxes']) && count($balances['cashboxes']) > 0): ?>
        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Kasalar</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Kasa</th>
                                    <th class="text-end">Bakiye</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $balances['cashboxes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cashbox['name']); ?></td>
                                        <td class="text-end">
                                            <strong class="<?php echo e($cashbox['balance'] >= 0 ? 'text-success' : 'text-danger'); ?>">
                                                <?php echo e(number_format($cashbox['balance'], 2)); ?> ₺
                                            </strong>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td><strong>Toplam</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($balances['total_cash'] ?? 0, 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if(isset($balances['bank_accounts']) && count($balances['bank_accounts']) > 0): ?>
        <div class="col-md-6 mb-4">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0">Banka Hesapları</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Banka</th>
                                    <th class="text-end">Bakiye</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $balances['bank_accounts']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($bank['name']); ?></td>
                                        <td class="text-end">
                                            <strong class="<?php echo e($bank['balance'] >= 0 ? 'text-success' : 'text-danger'); ?>">
                                                <?php echo e(number_format($bank['balance'], 2)); ?> ₺
                                            </strong>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="table-info">
                                    <td><strong>Toplam</strong></td>
                                    <td class="text-end">
                                        <strong><?php echo e(number_format($balances['total_bank'] ?? 0, 2)); ?> ₺</strong>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if(isset($balances['total'])): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center">
            <h4 class="mb-0">
                Toplam Nakit: 
                <span class="<?php echo e($balances['total'] >= 0 ? 'text-success' : 'text-danger'); ?>">
                    <?php echo e(number_format($balances['total'], 2)); ?> ₺
                </span>
            </h4>
            <small class="text-muted">Tarih: <?php echo e(\Carbon\Carbon::parse($asOfDate)->format('d.m.Y')); ?></small>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aytacipekela/PHP-Projects/muhasebe/resources/views/accounting/reports/cash-bank-balance.blade.php ENDPATH**/ ?>